'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import {
  Coffee, Users, Search, Plus,
  ChevronLeft, ChevronRight, Loader2,
  Check, Eye,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useI18n } from '@/i18n'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { toast } from 'sonner'
import { DashboardShell } from '@/components/layout/dashboard-shell'

interface Farmer {
  id: string
  farmerCode: string | null
  fullName: string
  contactNumber: string
  email?: string | null
  gender?: string | null
  age?: number | null
  province?: string | null
  district?: string | null
  commune?: string | null
  village?: string | null
  isCertified: boolean
  certificationType?: string | null
  cooperative?: string | null
  creditScore?: number | null
  yearsOfFarmingExperience?: number | null
  nationalIdNo?: string | null
  loanTaken: boolean
  loanAmount?: number | null
  smartphoneOwnership: boolean
  gapTrainingAttended: boolean
  isActive: boolean
  createdAt: string
}

export default function FarmersPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { t, t2, lang } = useI18n()
  const [farmers, setFarmers] = useState<Farmer[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageSize] = useState(10)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingFarmer, setEditingFarmer] = useState<Farmer | null>(null)
  const [submitting, setSubmitting] = useState(false)


  // Form state
  const [form, setForm] = useState({
    fullName: '',
    contactNumber: '',
    email: '',
    gender: 'Male',
    age: '',
    province: '',
    district: '',
    commune: '',
    village: '',
    isCertified: false,
    certificationType: '',
    cooperative: '',
    nationalIdNo: '',
    yearsOfFarmingExperience: '',
    creditScore: '',
    loanTaken: false,
    loanAmount: '',
    smartphoneOwnership: false,
    gapTrainingAttended: false,
    ekycConsent: false,
  })

  const resetForm = () => {
    setForm({
      fullName: '', contactNumber: '', email: '', gender: 'Male',
      age: '', province: '', district: '', commune: '', village: '',
      isCertified: false, certificationType: '', cooperative: '',
      nationalIdNo: '', yearsOfFarmingExperience: '', creditScore: '',
      loanTaken: false, loanAmount: '', smartphoneOwnership: false,
      gapTrainingAttended: false, ekycConsent: false,
    })
    setEditingFarmer(null)
  }

  const fetchFarmers = useCallback(async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        page: String(page),
        pageSize: String(pageSize),
        search,
        sortBy: 'createdAt',
        sortOrder: 'desc',
      })
      const res = await fetch(`/api/farmers?${params}`)
      const data = await res.json()
      if (data.success) {
        // API returns: { success: true, data: { data: [...farmers], total, page, ... } }
        const farmersList = data.data?.data ?? data.data?.farmers ?? []
        setFarmers(Array.isArray(farmersList) ? farmersList : [])
        setTotal(data.data?.total ?? 0)
      }
    } catch (err) {
      console.error('Failed to fetch farmers', err)
    } finally {
      setLoading(false)
    }
  }, [page, pageSize, search])

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login')
    } else if (status === 'authenticated') {
      fetchFarmers()
    }
  }, [status, router, fetchFarmers])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      const payload = {
        ...form,
        age: form.age ? parseInt(form.age) : undefined,
        yearsOfFarmingExperience: form.yearsOfFarmingExperience ? parseInt(form.yearsOfFarmingExperience) : undefined,
        creditScore: form.creditScore ? parseFloat(form.creditScore) : undefined,
        loanAmount: form.loanAmount ? parseFloat(form.loanAmount) : undefined,
      }

      const res = await fetch('/api/farmers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(t2('Tạo nông dân thành công!', 'Farmer created!'))
        setDialogOpen(false)
        resetForm()
        fetchFarmers()
      } else {
        toast.error(data.error || t2('Lỗi khi tạo nông dân', 'Error creating farmer'))
      }
    } catch {
      toast.error(t2('Lỗi kết nối', 'Connection error'))
    } finally {
      setSubmitting(false)
    }
  }

  const totalPages = Math.ceil(total / pageSize)

  if (status === 'loading' || (loading && farmers.length === 0)) {
    return (
      <DashboardShell>
        <div className="flex items-center justify-center py-32">
          <div className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center">
              <Coffee className="w-9 h-9 text-white animate-pulse" />
            </div>
            <div className="flex items-center gap-2 text-foreground">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">{t2('Đang tải...', 'Loading...')}</span>
            </div>
          </div>
        </div>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <div>
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-foreground flex items-center gap-2">
              <Users className="w-5 h-5 text-foreground" />
              {t2('Quản lý Nông dân', 'Farmer Management')}
            </h2>
            <p className="text-sm text-foreground">{t(`Tổng số: ${total} nông dân`, `Total: ${total} farmers`)}</p>
          </div>

          <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) resetForm() }}>
            <DialogTrigger asChild>
              <Button
                className="btn-primary-gradient gap-2 rounded-xl shadow-sm"
                onClick={() => { resetForm(); setDialogOpen(true) }}
              >
                <Plus className="w-4 h-4" />
                {t2('Thêm nông dân mới', 'Add New Farmer')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl">
              <DialogHeader>
                <DialogTitle className="text-foreground flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  {editingFarmer ? t2('Sửa thông tin nông dân', 'Edit Farmer') : t2('Thêm nông dân mới', 'Add New Farmer')}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* FullName */}
                  <div className="space-y-1.5 md:col-span-2">
                    <Label className="text-xs text-foreground">{t2('Họ và tên', 'Full Name')} *</Label>
                    <Input
                      value={form.fullName}
                      onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                      placeholder={t2('Nhập họ và tên', 'Enter full name')}
                      className="rounded-xl border-border focus:border-border"
                      required
                    />
                  </div>

                  {/* Contact Number */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Số điện thoại', 'Contact Number')} *</Label>
                    <Input
                      value={form.contactNumber}
                      onChange={(e) => setForm({ ...form, contactNumber: e.target.value })}
                      placeholder="0912345678"
                      className="rounded-xl border-border focus:border-border"
                      required
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Email', 'Email')}</Label>
                    <Input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="email@example.com"
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* Gender */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Giới tính', 'Gender')}</Label>
                    <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v })}>
                      <SelectTrigger className="rounded-xl border-border">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Male">{t2('Nam', 'Male')}</SelectItem>
                        <SelectItem value="Female">{t2('Nữ', 'Female')}</SelectItem>
                        <SelectItem value="Other">{t2('Khác', 'Other')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Age */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Tuổi', 'Age')}</Label>
                    <Input
                      type="number"
                      value={form.age}
                      onChange={(e) => setForm({ ...form, age: e.target.value })}
                      placeholder="35"
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* Province */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Tỉnh/Thành phố', 'Province')}</Label>
                    <Input
                      value={form.province}
                      onChange={(e) => setForm({ ...form, province: e.target.value })}
                      placeholder={t2('Lâm Đồng', 'Lam Dong')}
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* District */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Quận/Huyện', 'District')}</Label>
                    <Input
                      value={form.district}
                      onChange={(e) => setForm({ ...form, district: e.target.value })}
                      placeholder={t2('Đà Lạt', 'Da Lat')}
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* Commune */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Xã/Phường', 'Commune')}</Label>
                    <Input
                      value={form.commune}
                      onChange={(e) => setForm({ ...form, commune: e.target.value })}
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* Village */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Thôn/Bản', 'Village')}</Label>
                    <Input
                      value={form.village}
                      onChange={(e) => setForm({ ...form, village: e.target.value })}
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* National ID */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Số CMND/CCCD', 'National ID')}</Label>
                    <Input
                      value={form.nationalIdNo}
                      onChange={(e) => setForm({ ...form, nationalIdNo: e.target.value })}
                      placeholder="079201012345"
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* Years of Experience */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Kinh nghiệm (năm)', 'Experience (years)')}</Label>
                    <Input
                      type="number"
                      value={form.yearsOfFarmingExperience}
                      onChange={(e) => setForm({ ...form, yearsOfFarmingExperience: e.target.value })}
                      placeholder="10"
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* Credit Score */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Điểm tín dụng', 'Credit Score')}</Label>
                    <Input
                      type="number"
                      value={form.creditScore}
                      onChange={(e) => setForm({ ...form, creditScore: e.target.value })}
                      placeholder="80"
                      min="0" max="100"
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>

                  {/* Cooperative */}
                  <div className="space-y-1.5">
                    <Label className="text-xs text-foreground">{t2('Hợp tác xã', 'Cooperative')}</Label>
                    <Input
                      value={form.cooperative}
                      onChange={(e) => setForm({ ...form, cooperative: e.target.value })}
                      placeholder={t2('HTX Cà phê Metrang', 'Metrang Coffee Co-op')}
                      className="rounded-xl border-border focus:border-border"
                    />
                  </div>
                </div>

                {/* Checkboxes */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="isCertified"
                      checked={form.isCertified}
                      onCheckedChange={(v) => setForm({ ...form, isCertified: !!v })}
                    />
                    <Label htmlFor="isCertified" className="text-xs text-foreground">{t2('Đã chứng nhận', 'Certified')}</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="loanTaken"
                      checked={form.loanTaken}
                      onCheckedChange={(v) => setForm({ ...form, loanTaken: !!v })}
                    />
                    <Label htmlFor="loanTaken" className="text-xs text-foreground">{t2('Có vay vốn', 'Has Loan')}</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="smartphone"
                      checked={form.smartphoneOwnership}
                      onCheckedChange={(v) => setForm({ ...form, smartphoneOwnership: !!v })}
                    />
                    <Label htmlFor="smartphone" className="text-xs text-foreground">{t2('Có điện thoại', 'Has Smartphone')}</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="gapTraining"
                      checked={form.gapTrainingAttended}
                      onCheckedChange={(v) => setForm({ ...form, gapTrainingAttended: !!v })}
                    />
                    <Label htmlFor="gapTraining" className="text-xs text-foreground">{t2('Đào tạo GAP', 'GAP Training')}</Label>
                  </div>
                </div>

                {/* Submit */}
                <div className="flex justify-end gap-3 pt-4 border-t border-border">
                  <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); resetForm() }} className="rounded-xl">
                    {t2('Hủy', 'Cancel')}
                  </Button>
                  <Button
                    type="submit"
                    disabled={submitting}
                    className="btn-primary-gradient rounded-xl"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {t2('Đang lưu...', 'Saving...')}
                      </>
                    ) : (
                      t2('Tạo mới', 'Create')
                    )}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <div className="flex items-center gap-3 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-foreground" />
            <Input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1) }}
              placeholder={t2('Tìm kiếm nông dân...', 'Search farmers...')}
              className="pl-9 rounded-xl border-border focus:border-border bg-background"
            />
          </div>
          <Badge variant="outline" className="border-border text-foreground text-xs">
            {t(`${total} bản ghi`, `${total} records`)}
          </Badge>
        </div>

        {/* Farmers Table */}
        <Card className="rounded-2xl border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-muted border-b border-border">
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider">{t2('Mã', 'Code')}</th>
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider">{t2('Họ và tên', 'Full Name')}</th>
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider hidden md:table-cell">{t2('Số ĐT', 'Contact')}</th>
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider hidden lg:table-cell">{t2('Tỉnh', 'Province')}</th>
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider hidden md:table-cell">{t2('CC', 'Cert')}</th>
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider hidden lg:table-cell">{t2('Điểm TD', 'Credit')}</th>
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider">{t2('Trạng thái', 'Status')}</th>
                  <th className="px-4 py-3 text-[10px] font-bold text-foreground uppercase tracking-wider">{t2('Hành động', 'Actions')}</th>
                </tr>
              </thead>
              <tbody>
                {(farmers || []).map((farmer, i) => (
                    <tr key={farmer.id}
 className="border-b border-border hover:bg-muted/50 transition-colors">
                      <td className="px-4 py-3 text-xs text-foreground font-mono">{farmer.farmerCode || '-'}</td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="text-xs font-medium text-foreground">{farmer.fullName}</p>
                          <p className="text-[10px] text-foreground">{farmer.gender} {farmer.age ? `• ${farmer.age}` + t2(' tuổi', ' yrs') : ''}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-foreground hidden md:table-cell">{farmer.contactNumber}</td>
                      <td className="px-4 py-3 text-xs text-foreground hidden lg:table-cell">
                        {farmer.province || '-'}
                        {farmer.district ? <span className="text-foreground"> • {farmer.district}</span> : null}
                      </td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        {farmer.isCertified ? (
                          <Badge className="bg-green-100 text-green-700 text-[10px] border-0">{t2('Đã CC', 'Certified')}</Badge>
                        ) : (
                          <Badge variant="outline" className="text-[10px] border-border text-foreground">{t2('Chưa', 'No')}</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-foreground hidden lg:table-cell">
                        {farmer.creditScore !== null && farmer.creditScore !== undefined ? (
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full bg-primary"
                                style={{ width: `${farmer.creditScore}%` }}
                              />
                            </div>
                            <span className="text-[10px]">{farmer.creditScore}</span>
                          </div>
                        ) : '-'}
                      </td>
                      <td className="px-4 py-3">
                        <Badge className={`${farmer.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'} text-[10px] border-0`}>
                          {farmer.isActive ? t2('Hoạt động', 'Active') : t2('Không HĐ', 'Inactive')}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground" onClick={() => router.push(`/farmers/${farmer.id}`)} title={t2('Xem chi tiết', 'View Details')}>
                            <Eye className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
</tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <p className="text-[10px] text-foreground">
                {t(`Trang ${page}/${totalPages}`, `Page ${page}/${totalPages}`)}
              </p>
              <div className="flex items-center gap-1">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page <= 1}
                  onClick={() => setPage(page - 1)}
                  className="h-7 w-7 p-0 rounded-lg border-border"
                >
                  <ChevronLeft className="w-3 h-3" />
                </Button>
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i
                  if (p > totalPages) return null
                  return (
                    <Button
                      key={p}
                      variant={p === page ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setPage(p)}
                      className={`h-7 w-7 p-0 rounded-lg text-[10px] ${p === page ? 'bg-muted text-white' : 'border-border text-foreground'}`}
                    >
                      {p}
                    </Button>
                  )
                })}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page >= totalPages}
                  onClick={() => setPage(page + 1)}
                  className="h-7 w-7 p-0 rounded-lg border-border"
                >
                  <ChevronRight className="w-3 h-3" />
                </Button>
              </div>
            </div>
          )}
        </Card>
      </div>
    </DashboardShell>
  )
}
