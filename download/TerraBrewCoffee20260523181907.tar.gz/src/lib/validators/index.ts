/**
 * Zod validation schemas for all API endpoints.
 * Every API route MUST validate input with these schemas.
 */
import { z } from 'zod'

// ════════════════════════════════════════════════════════════════
// AUTH SCHEMAS
// ════════════════════════════════════════════════════════════════

export const tenantLoginSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  tenantSlug: z.string().min(1, 'Tenant slug required'),
})

export const platformLoginSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
})

export const registerUserSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email format'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  phone: z.string().optional(),
  role: z.enum(['tenant_admin', 'manager', 'inspector', 'field_officer', 'farmer', 'viewer']),
})

// ════════════════════════════════════════════════════════════════
// SUPER ADMIN SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createTenantSchema = z.object({
  name: z.string().min(2, 'Tenant name required'),
  slug: z.string().min(2, 'Slug required').regex(/^[a-z0-9-]+$/, 'Slug must be lowercase alphanumeric with dashes'),
  legalName: z.string().optional(),
  taxId: z.string().optional(),
  currency: z.string().default('VND'),
  currencySymbol: z.string().default('₫'),
  language: z.string().default('vi'),
  timezone: z.string().default('Asia/Ho_Chi_Minh'),
  country: z.string().default('VN'),
  plan: z.enum(['starter', 'professional', 'enterprise']).default('starter'),
  maxUsers: z.number().int().positive().default(10),
  maxFarmers: z.number().int().positive().default(500),
  enabledModules: z.record(z.string(), z.boolean()).default({}),
})

export const updateTenantSchema = z.object({
  tenantId: z.string().min(1, 'Tenant ID required'),
  name: z.string().min(2, 'Tenant name required').optional(),
  slug: z.string().min(2, 'Slug required').regex(/^[a-z0-9-]+$/, 'Slug must be lowercase alphanumeric with dashes').optional(),
  legalName: z.string().optional(),
  taxId: z.string().optional(),
  currency: z.string().optional(),
  currencySymbol: z.string().optional(),
  language: z.string().optional(),
  timezone: z.string().optional(),
  country: z.string().optional(),
  plan: z.enum(['starter', 'professional', 'enterprise']).optional(),
  maxUsers: z.number().int().positive().optional(),
  maxFarmers: z.number().int().positive().optional(),
  enabledModules: z.record(z.string(), z.boolean()).optional(),
  isActive: z.boolean().optional(),
})

export const updateModuleConfigSchema = z.object({
  enabledModules: z.record(z.string(), z.boolean()),
})

// ════════════════════════════════════════════════════════════════
// PLATFORM USER SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createPlatformUserSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  name: z.string().min(2, 'Name must be at least 2 characters'),
  role: z.enum(['super_admin', 'support']).default('support'),
})

export const updatePlatformUserSchema = z.object({
  userId: z.string().min(1, 'User ID required'),
  email: z.string().email('Invalid email format').optional(),
  password: z.string().min(8, 'Password must be at least 8 characters').optional(),
  name: z.string().min(2, 'Name must be at least 2 characters').optional(),
  role: z.enum(['super_admin', 'support']).optional(),
  isActive: z.boolean().optional(),
})

// ════════════════════════════════════════════════════════════════
// FARMER SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createFarmerSchema = z.object({
  farmerCode: z.string().optional(),
  enrollmentPlace: z.string().optional(),
  isCertified: z.boolean().default(false),
  certificationType: z.string().optional(),
  yearOfICS: z.string().optional(),
  cooperative: z.string().optional(),
  fullName: z.string().min(2, 'Full name required'),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  middleName: z.string().optional(),
  contactNumber: z.string().min(1, 'Contact number required'),
  gender: z.enum(['Male', 'Female', 'Other']).optional(),
  dob: z.string().optional(),
  age: z.number().int().positive().optional(),
  education: z.string().optional(),
  maritalStatus: z.string().optional(),
  nationalIdType: z.string().optional(),
  nationalIdNo: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  country: z.string().optional(),
  province: z.string().optional(),
  district: z.string().optional(),
  commune: z.string().optional(),
  village: z.string().optional(),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
  yearsOfFarmingExperience: z.number().int().min(0).optional(),
  creditScore: z.number().min(0).max(100).optional(),
  loanTaken: z.boolean().default(false),
  loanAmount: z.number().nonnegative().optional(),
  smartphoneOwnership: z.boolean().default(false),
  gapTrainingAttended: z.boolean().default(false),
  ekycConsent: z.boolean().default(false),
})

export const updateFarmerSchema = createFarmerSchema.partial()

// ════════════════════════════════════════════════════════════════
// FARM LAND SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createFarmLandSchema = z.object({
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmName: z.string().min(1, 'Farm name required'),
  plotBlockId: z.string().optional(),
  totalLandHolding: z.number().positive().optional(),
  altitude: z.number().positive().optional(),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
  landOwnership: z.string().optional(),
  soilType: z.string().optional(),
  waterSource: z.string().optional(),
  noOfTrees: z.number().int().positive().optional(),
  estYield: z.number().positive().optional(),
  childLabourPolicy: z.boolean().default(false),
  minimumWageCompliance: z.boolean().default(false),
  ppeAvailable: z.boolean().default(false),
})

export const updateFarmLandSchema = createFarmLandSchema.partial()

// ════════════════════════════════════════════════════════════════
// CULTIVATION SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createCultivationSchema = z.object({
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmLandId: z.string().min(1, 'Farm land ID required'),
  farmPlotName: z.string().min(1, 'Plot name required'),
  cultivatedCrop: z.string().optional(),
  cropVariety: z.string().optional(),
  cultivationArea: z.number().positive().optional(),
  sowingDate: z.string().optional(),
  estYield: z.string().optional(),
  seedSource: z.string().optional(),
  seedType: z.string().optional(),
  seedQuantity: z.number().nonnegative().optional(),
  seedCost: z.number().nonnegative().optional(),
})

export const updateCultivationSchema = createCultivationSchema.partial()

// ════════════════════════════════════════════════════════════════
// HARVEST TRACEABILITY SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createHarvestTraceSchema = z.object({
  cultivationId: z.string().min(1, 'Cultivation ID required'),
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmLandId: z.string().min(1, 'Farm land ID required'),
  coffeeVariety: z.string().optional(),
  actualHarvestDate: z.string().optional(),
  harvestMethod: z.string().default('Selective Picking'),
  cherryRipeness: z.number().min(0).max(100).optional(),
  cupScore: z.number().min(0).max(100).optional(),
  processingMethod: z.string().optional(),
  moistureContent: z.number().min(0).max(100).optional(),
  batchNotes: z.string().optional(),
})

export const updateHarvestTraceSchema = createHarvestTraceSchema.partial()

// ════════════════════════════════════════════════════════════════
// GENERIC PAGINATION
// ════════════════════════════════════════════════════════════════

export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().positive().max(100).default(20),
  search: z.string().optional(),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
})

export type PaginationInput = z.infer<typeof paginationSchema>

// ════════════════════════════════════════════════════════════════
// 1. NURSERY SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createNurserySchema = z.object({
  farmerId: z.string().optional(),
  nurseryName: z.string().min(1, 'Nursery name required'),
  nurseryCode: z.string().optional(),
  location: z.string().optional(),
  province: z.string().optional(),
  district: z.string().optional(),
  commune: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  nurseryType: z.string().optional(),
  capacity: z.number().int().optional(),
  currentStock: z.number().int().optional(),
  species: z.string().optional(),
  variety: z.string().optional(),
  seedSource: z.string().optional(),
  plantingDate: z.string().optional(),
  expectedReadyDate: z.string().optional(),
  germinationRate: z.number().optional(),
  survivalRate: z.number().optional(),
  healthStatus: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateNurserySchema = createNurserySchema.partial()

// ════════════════════════════════════════════════════════════════
// 2. LAND PREPARATION SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createLandPreparationSchema = z.object({
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmLandId: z.string().min(1, 'Farm land ID required'),
  preparationDate: z.string().optional(),
  preparationType: z.string().optional(),
  method: z.string().optional(),
  equipmentUsed: z.string().optional(),
  laborCount: z.number().int().optional(),
  laborCost: z.number().optional(),
  materialsUsed: z.string().optional(),
  materialCost: z.number().optional(),
  totalCost: z.number().optional(),
  soilPhBefore: z.number().optional(),
  soilPhAfter: z.number().optional(),
  organicMatterPct: z.number().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateLandPreparationSchema = createLandPreparationSchema.partial()

// ════════════════════════════════════════════════════════════════
// 3. CROP MONITORING SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createCropMonitoringSchema = z.object({
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmLandId: z.string().min(1, 'Farm land ID required'),
  cultivationId: z.string().optional(),
  monitoringDate: z.string().optional(),
  monitoringType: z.string().optional(),
  growthStage: z.string().optional(),
  plantHeight: z.number().optional(),
  canopyDiameter: z.number().optional(),
  leafColor: z.string().optional(),
  healthScore: z.number().optional(),
  pestPressure: z.string().optional(),
  diseaseSymptoms: z.string().optional(),
  weatherCondition: z.string().optional(),
  temperature: z.number().optional(),
  rainfall: z.number().optional(),
  humidity: z.number().optional(),
  soilMoisture: z.number().optional(),
  alertTriggered: z.boolean().default(false),
  alertType: z.string().optional(),
  alertSeverity: z.string().optional(),
  remedialAction: z.string().optional(),
  photoUrl: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateCropMonitoringSchema = createCropMonitoringSchema.partial()

// ════════════════════════════════════════════════════════════════
// 4. FERTILIZER APPLICATION SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createFertilizerAppSchema = z.object({
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmLandId: z.string().min(1, 'Farm land ID required'),
  cultivationId: z.string().optional(),
  applicationDate: z.string().optional(),
  fertilizerType: z.string().optional(),
  fertilizerName: z.string().optional(),
  nutrientContent: z.string().optional(),
  applicationRate: z.number().optional(),
  unit: z.string().optional(),
  totalQuantity: z.number().optional(),
  applicationMethod: z.string().optional(),
  costPerUnit: z.number().optional(),
  totalCost: z.number().optional(),
  weatherAtApplication: z.string().optional(),
  appliedBy: z.string().optional(),
  isOrganic: z.boolean().default(false),
  certificationNumber: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateFertilizerAppSchema = createFertilizerAppSchema.partial()

// ════════════════════════════════════════════════════════════════
// 5. PEST DISEASE MANAGEMENT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createPestDiseaseSchema = z.object({
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmLandId: z.string().min(1, 'Farm land ID required'),
  cultivationId: z.string().optional(),
  detectionDate: z.string().optional(),
  pestOrDisease: z.string().optional(),
  type: z.string().optional(),
  severity: z.string().optional(),
  affectedArea: z.number().optional(),
  affectedTrees: z.number().int().optional(),
  symptoms: z.string().optional(),
  treatmentMethod: z.string().optional(),
  treatmentProduct: z.string().optional(),
  dosage: z.string().optional(),
  applicationDate: z.string().optional(),
  followUpDate: z.string().optional(),
  outcome: z.string().optional(),
  cost: z.number().optional(),
  preventionMeasures: z.string().optional(),
  photoUrl: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updatePestDiseaseSchema = createPestDiseaseSchema.partial()

// ════════════════════════════════════════════════════════════════
// 6. COLLECTION CENTRE SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createCollectionCentreSchema = z.object({
  centreId: z.string().optional(),
  centreName: z.string().min(1, 'Centre name required'),
  centreGpsLat: z.number().optional(),
  centreGpsLng: z.number().optional(),
  province: z.string().optional(),
  district: z.string().optional(),
  commune: z.string().optional(),
  address: z.string().optional(),
  managerName: z.string().optional(),
  contactNumber: z.string().optional(),
  storageCapacityKg: z.number().optional(),
  scaleType: z.string().optional(),
  operatingHours: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateCollectionCentreSchema = createCollectionCentreSchema.partial()

// ════════════════════════════════════════════════════════════════
// 7. PROCUREMENT RECORD SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createProcurementSchema = z.object({
  farmerId: z.string().min(1, 'Farmer ID required'),
  farmLandId: z.string().optional(),
  collectionCentreId: z.string().optional(),
  cultivationId: z.string().optional(),
  procurementId: z.string().optional(),
  procurementDate: z.string().optional(),
  batchId: z.string().optional(),
  coffeeType: z.string().optional(),
  coffeeVariety: z.string().optional(),
  grossWeight: z.number().optional(),
  tareWeight: z.number().optional(),
  netWeight: z.number().optional(),
  moistureContentAtGate: z.number().optional(),
  adjustedNetWeight: z.number().optional(),
  cherryRipenessGrade: z.string().optional(),
  defects: z.number().optional(),
  purchasePricePerKg: z.number().optional(),
  totalPurchaseAmount: z.number().optional(),
  priceBasis: z.string().optional(),
  certPremiumApplied: z.number().optional(),
  paymentMethod: z.string().optional(),
  paymentStatus: z.string().optional(),
  paymentDate: z.string().optional(),
  transportId: z.string().optional(),
  vehicleNumber: z.string().optional(),
  driverName: z.string().optional(),
  departureTime: z.string().optional(),
  arrivalTime: z.string().optional(),
  destination: z.string().optional(),
  transportCost: z.number().optional(),
  transportNotes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateProcurementSchema = createProcurementSchema.partial()

// ════════════════════════════════════════════════════════════════
// 8. PROCESSING JOB ORDER SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createProcessingJobSchema = z.object({
  jobOrderId: z.string().optional(),
  processingDate: z.string().optional(),
  batchIdInput: z.string().optional(),
  coffeeTypeInput: z.string().optional(),
  coffeeVarietyInput: z.string().optional(),
  inputQuantityKg: z.number().optional(),
  processingMethod: z.string().optional(),
  targetOutputProduct: z.string().optional(),
  operatorName: z.string().optional(),
  plantFacilityName: z.string().optional(),
  inputWeightKg: z.number().optional(),
  finalOutputWeightKg: z.number().optional(),
  overallOutturn: z.number().optional(),
  totalProcessingCost: z.number().optional(),
  costPerKg: z.number().optional(),
  finalMoistureContent: z.number().optional(),
  cupScore: z.number().optional(),
  cuppingNotes: z.string().optional(),
  qcApprovedBy: z.string().optional(),
  qcApprovalDate: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateProcessingJobSchema = createProcessingJobSchema.partial()

// ════════════════════════════════════════════════════════════════
// 9. CERT ASSESSMENT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createCertAssessmentSchema = z.object({
  farmerId: z.string().optional(),
  farmLandId: z.string().optional(),
  assessmentId: z.string().optional(),
  assessmentDate: z.string().optional(),
  certificationStandard: z.string().optional(),
  certifyingBody: z.string().optional(),
  assessmentType: z.string().optional(),
  scope: z.string().optional(),
  status: z.enum(['pending', 'in_progress', 'completed', 'failed']).optional(),
  score: z.number().optional(),
  maxScore: z.number().optional(),
  findings: z.string().optional(),
  nonConformities: z.string().optional(),
  correctiveActions: z.string().optional(),
  validFrom: z.string().optional(),
  validUntil: z.string().optional(),
  certificateNumber: z.string().optional(),
  certificateDocumentUrl: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateCertAssessmentSchema = createCertAssessmentSchema.partial()

// ════════════════════════════════════════════════════════════════
// 10. COFFEE INSPECTION SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createCoffeeInspectionSchema = z.object({
  farmerId: z.string().optional(),
  farmLandId: z.string().optional(),
  batchId: z.string().optional(),
  inspectionId: z.string().optional(),
  inspectionDate: z.string().optional(),
  inspectorName: z.string().optional(),
  inspectorCertNo: z.string().optional(),
  inspectionType: z.string().optional(),
  inspectionStandard: z.string().optional(),
  sampleSize: z.number().optional(),
  moistureContent: z.number().optional(),
  defectCount: z.number().optional(),
  foreignMatter: z.number().optional(),
  screenSize: z.string().optional(),
  color: z.string().optional(),
  aroma: z.string().optional(),
  taste: z.string().optional(),
  body: z.string().optional(),
  acidity: z.string().optional(),
  aftertaste: z.string().optional(),
  cupScore: z.number().optional(),
  overallGrade: z.string().optional(),
  passFail: z.enum(['Pass', 'Fail', 'Conditional']).optional(),
  remarks: z.string().optional(),
  photoUrl: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateCoffeeInspectionSchema = createCoffeeInspectionSchema.partial()

// ════════════════════════════════════════════════════════════════
// 11. SMART CONTRACT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createSmartContractSchema = z.object({
  farmerId: z.string().optional(),
  buyerId: z.string().optional(),
  contractId: z.string().optional(),
  contractType: z.string().optional(),
  title: z.string().optional(),
  description: z.string().optional(),
  partyA: z.string().optional(),
  partyB: z.string().optional(),
  quantityKg: z.number().optional(),
  pricePerKg: z.number().optional(),
  totalValue: z.number().optional(),
  currency: z.string().optional(),
  deliveryDate: z.string().optional(),
  deliveryLocation: z.string().optional(),
  qualityGrade: z.string().optional(),
  terms: z.string().optional(),
  status: z.enum(['draft', 'pending', 'active', 'completed', 'terminated']).optional(),
  signedByA: z.boolean().default(false),
  signedByB: z.boolean().default(false),
  signedDateA: z.string().optional(),
  signedDateB: z.string().optional(),
  effectiveDate: z.string().optional(),
  expiryDate: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateSmartContractSchema = createSmartContractSchema.partial()

// ════════════════════════════════════════════════════════════════
// 12. MARKETPLACE LISTING SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createMarketplaceListingSchema = z.object({
  farmerId: z.string().optional(),
  listingId: z.string().optional(),
  title: z.string().min(1, 'Title required'),
  description: z.string().optional(),
  coffeeType: z.string().optional(),
  coffeeVariety: z.string().optional(),
  grade: z.string().optional(),
  quantityKg: z.number().optional(),
  pricePerKg: z.number().optional(),
  totalValue: z.number().optional(),
  currency: z.string().optional(),
  origin: z.string().optional(),
  processingMethod: z.string().optional(),
  cupScore: z.number().optional(),
  certifications: z.string().optional(),
  harvestYear: z.string().optional(),
  availability: z.string().optional(),
  listingStatus: z.enum(['active', 'paused', 'sold', 'expired']).optional(),
  listingDate: z.string().optional(),
  expiryDate: z.string().optional(),
  buyerId: z.string().optional(),
  saleDate: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateMarketplaceListingSchema = createMarketplaceListingSchema.partial()

// ════════════════════════════════════════════════════════════════
// 13. EUDR COMPLIANCE SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createEudrComplianceSchema = z.object({
  batchId: z.string().optional(),
  farmerId: z.string().optional(),
  farmLandId: z.string().optional(),
  complianceId: z.string().optional(),
  status: z.enum(['pending', 'in_review', 'compliant', 'non_compliant', 'expired']).default('pending'),
  riskLevel: z.enum(['low', 'medium', 'high', 'critical']).optional(),
  deforestationRiskScore: z.number().optional(),
  satelliteImageryRef: z.string().optional(),
  geolocationLat: z.number().optional(),
  geolocationLng: z.number().optional(),
  landUseType: z.string().optional(),
  landCoverChangeDate: z.string().optional(),
  verificationDate: z.string().optional(),
  verifiedBy: z.string().optional(),
  dueDiligenceStatement: z.string().optional(),
  tracesCertificateRef: z.string().optional(),
  validFrom: z.string().optional(),
  validUntil: z.string().optional(),
  notes: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateEudrComplianceSchema = createEudrComplianceSchema.partial()

// ════════════════════════════════════════════════════════════════
// 14. DEFORESTATION ASSESSMENT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createDeforestationSchema = z.object({
  farmLandId: z.string().optional(),
  eudrComplianceId: z.string().optional(),
  assessmentDate: z.string().optional(),
  dataSource: z.enum(['satellite', 'ground_survey', 'combined']).default('satellite'),
  provider: z.string().optional(),
  referencePeriodStart: z.string().optional(),
  referencePeriodEnd: z.string().optional(),
  forestCoverBaselinePct: z.number().optional(),
  currentForestCoverPct: z.number().optional(),
  forestLossPct: z.number().optional(),
  deforestationDetected: z.boolean().default(false),
  riskScore: z.number().optional(),
  riskCategory: z.enum(['negligible', 'low', 'medium', 'high', 'critical']).optional(),
  imageryUrl: z.string().optional(),
  analysisReportUrl: z.string().optional(),
  methodology: z.string().optional(),
  confidenceLevel: z.number().optional(),
  validUntil: z.string().optional(),
  notes: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateDeforestationSchema = createDeforestationSchema.partial()

// ════════════════════════════════════════════════════════════════
// 15. EXPORT DOCUMENT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createExportDocSchema = z.object({
  shipmentId: z.string().optional(),
  documentType: z.enum([
    'eudr_dds',
    'phytosanitary',
    'certificate_of_origin',
    'commercial_invoice',
    'bill_of_lading',
    'packing_list',
    'customs_declaration',
  ]),
  documentNumber: z.string().optional(),
  issuingAuthority: z.string().optional(),
  issueDate: z.string().optional(),
  expiryDate: z.string().optional(),
  status: z.enum(['draft', 'pending_approval', 'approved', 'rejected', 'expired']).default('draft'),
  fileUrl: z.string().optional(),
  verifiedBy: z.string().optional(),
  verifiedDate: z.string().optional(),
  notes: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateExportDocSchema = createExportDocSchema.partial()

// ════════════════════════════════════════════════════════════════
// 16. SHIPMENT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createShipmentSchema = z.object({
  buyerId: z.string().optional(),
  shipmentId: z.string().optional(),
  status: z.enum(['planned', 'booked', 'in_transit', 'arrived', 'delivered', 'cancelled']).default('planned'),
  originCountry: z.string().optional(),
  destinationCountry: z.string().optional(),
  portOfLoading: z.string().optional(),
  portOfDischarge: z.string().optional(),
  vesselName: z.string().optional(),
  vesselImo: z.string().optional(),
  containerNumber: z.string().optional(),
  bookingNumber: z.string().optional(),
  billOfLadingNumber: z.string().optional(),
  estimatedDeparture: z.string().optional(),
  actualDeparture: z.string().optional(),
  estimatedArrival: z.string().optional(),
  actualArrival: z.string().optional(),
  totalWeightKg: z.number().optional(),
  totalBags: z.number().int().optional(),
  commodity: z.string().default('coffee'),
  grade: z.string().optional(),
  contractReference: z.string().optional(),
  freightForwarder: z.string().optional(),
  customsBroker: z.string().optional(),
  shippingLine: z.string().optional(),
  trackingUrl: z.string().optional(),
  notes: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateShipmentSchema = createShipmentSchema.partial()

// ════════════════════════════════════════════════════════════════
// 17. BUYER SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createBuyerSchema = z.object({
  buyerCode: z.string().optional(),
  companyName: z.string().min(1, 'Company name required'),
  contactPerson: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  country: z.string().optional(),
  taxId: z.string().optional(),
  euRegistration: z.boolean().default(false),
  eoriNumber: z.string().optional(),
  tracesRegistration: z.string().optional(),
  buyerType: z.enum(['roaster', 'importer', 'trader', 'distributor']).default('roaster'),
  preferredCurrency: z.string().default('EUR'),
  paymentTerms: z.string().optional(),
  qualityRequirements: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateBuyerSchema = createBuyerSchema.partial()

// ════════════════════════════════════════════════════════════════
// 18. TRADING CONTRACT (TRADING DESK) SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createTradingDeskSchema = z.object({
  buyerId: z.string().min(1, 'Buyer ID required'),
  contractNumber: z.string().optional(),
  contractType: z.enum(['spot', 'forward', 'term']).default('spot'),
  commodity: z.string().default('coffee'),
  grade: z.string().optional(),
  quantityKg: z.number().optional(),
  pricePerKg: z.number().optional(),
  totalValue: z.number().optional(),
  currency: z.string().default('EUR'),
  qualitySpecs: z.string().optional(),
  deliveryDate: z.string().optional(),
  deliveryPort: z.string().optional(),
  paymentTerms: z.string().optional(),
  status: z.enum(['draft', 'pending', 'active', 'fulfilled', 'cancelled']).default('draft'),
  counterpartyVerified: z.boolean().default(false),
  qualityLinkedPricing: z.boolean().default(false),
  premiumDiscount: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateTradingDeskSchema = createTradingDeskSchema.partial()

// ════════════════════════════════════════════════════════════════
// 19. RFQ SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createRfqSchema = z.object({
  rfqId: z.string().optional(),
  title: z.string().min(1, 'Title required'),
  description: z.string().optional(),
  commodity: z.string().min(1, 'Commodity required'),
  variety: z.string().optional(),
  grade: z.string().optional(),
  quantityKg: z.number().optional(),
  targetPricePerKg: z.number().optional(),
  currency: z.string().optional(),
  deliveryLocation: z.string().optional(),
  deliveryDateFrom: z.string().optional(),
  deliveryDateTo: z.string().optional(),
  incoterms: z.string().optional(),
  originCountry: z.string().optional(),
  destinationCountry: z.string().optional(),
  certifications: z.string().optional(),
  processingMethod: z.string().optional(),
  cupScoreMin: z.number().optional(),
  status: z.enum(['draft', 'published', 'responded', 'awarded', 'cancelled', 'expired']).default('draft'),
  publishedAt: z.string().optional(),
  closesAt: z.string().optional(),
  awardedToResponseId: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateRfqSchema = createRfqSchema.partial()

// ════════════════════════════════════════════════════════════════
// 20. LOGISTICS BOOKING SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createLogisticsSchema = z.object({
  bookingId: z.string().optional(),
  bookingType: z.enum(['sea_freight', 'air_freight', 'land_transport', 'rail']).optional(),
  originCountry: z.string().optional(),
  originPort: z.string().optional(),
  destinationCountry: z.string().optional(),
  destinationPort: z.string().optional(),
  commodity: z.string().optional(),
  commodityCategory: z.string().optional(),
  totalWeightKg: z.number().optional(),
  totalVolumeCbm: z.number().optional(),
  containerType: z.enum(['20ft', '40ft', '40ft_hc', 'lcl']).optional(),
  containerCount: z.number().int().optional(),
  shippingLine: z.string().optional(),
  vesselName: z.string().optional(),
  voyageNumber: z.string().optional(),
  etd: z.string().optional(),
  atd: z.string().optional(),
  eta: z.string().optional(),
  ata: z.string().optional(),
  freightRate: z.number().optional(),
  currency: z.string().optional(),
  freightType: z.enum(['fcl', 'lcl']).optional(),
  incoterms: z.string().optional(),
  bookingStatus: z.enum(['draft', 'confirmed', 'in_transit', 'arrived', 'delivered', 'cancelled']).default('draft'),
  trackingUrl: z.string().optional(),
  blNumber: z.string().optional(),
  notes: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateLogisticsSchema = createLogisticsSchema.partial()

// ════════════════════════════════════════════════════════════════
// 21. IoT SENSOR SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createIoTSensorSchema = z.object({
  shipmentId: z.string().optional(),
  sensorType: z.enum(['temperature', 'humidity', 'gps', 'shock', 'light', 'co2']),
  deviceId: z.string().min(1, 'Device ID required'),
  deviceName: z.string().optional(),
  manufacturer: z.string().optional(),
  lastReading: z.string().optional(),
  lastReadingAt: z.string().optional(),
  batteryLevel: z.number().optional(),
  isActive: z.boolean().default(true),
})

export const updateIoTSensorSchema = createIoTSensorSchema.partial()

// ════════════════════════════════════════════════════════════════
// 22. QC VERIFICATION SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createQcVerificationSchema = z.object({
  certBodyId: z.string().optional(),
  verificationType: z.enum(['eudr', 'organic', 'fairtrade', 'rainforest', 'utz', '4c']),
  entityType: z.enum(['farmer', 'farmland', 'batch', 'shipment']),
  entityId: z.string().min(1, 'Entity ID required'),
  status: z.enum(['requested', 'scheduled', 'in_progress', 'passed', 'failed', 'expired']).default('requested'),
  scheduledDate: z.string().optional(),
  completedDate: z.string().optional(),
  inspectorName: z.string().optional(),
  inspectorCertNo: z.string().optional(),
  findings: z.string().optional(),
  certificateUrl: z.string().optional(),
  validUntil: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateQcVerificationSchema = createQcVerificationSchema.partial()

// ════════════════════════════════════════════════════════════════
// 23. TRACKING UPDATE SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createTrackingUpdateSchema = z.object({
  shipmentId: z.string().min(1, 'Shipment ID required'),
  updateType: z.enum(['departure', 'arrival', 'customs', 'transshipment', 'delivery', 'iot_reading']),
  location: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  timestamp: z.string().optional(),
  carrier: z.string().optional(),
  description: z.string().optional(),
  sensorData: z.string().optional(),
  reportedBy: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateTrackingUpdateSchema = createTrackingUpdateSchema.partial()

// ════════════════════════════════════════════════════════════════
// 24. COMPLIANCE BOOKING SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createComplianceBookingSchema = z.object({
  serviceId: z.string().min(1, 'Service ID required'),
  bookedBy: z.string().optional(),
  status: z.enum(['requested', 'confirmed', 'in_progress', 'completed', 'cancelled']).default('requested'),
  scheduledDate: z.string().optional(),
  completedDate: z.string().optional(),
  notes: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateComplianceBookingSchema = createComplianceBookingSchema.partial()

// ════════════════════════════════════════════════════════════════
// 25. WEBHOOK ENDPOINT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createWebhookSchema = z.object({
  url: z.string().url('Invalid URL format'),
  events: z.string().min(1, 'Events required'),
  secret: z.string().min(1, 'Secret required'),
  isActive: z.boolean().default(true),
  lastTriggeredAt: z.string().optional(),
  failureCount: z.number().int().default(0),
})

export const updateWebhookSchema = createWebhookSchema.partial()

// ════════════════════════════════════════════════════════════════
// 26. API KEY SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createApiKeySchema = z.object({
  name: z.string().min(1, 'Name required'),
  permissions: z.string().default('[]'),
  tier: z.enum(['starter', 'professional', 'enterprise']).default('starter'),
  rateLimitPerMin: z.number().int().positive().default(60),
  lastUsedAt: z.string().optional(),
  expiresAt: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateApiKeySchema = createApiKeySchema.partial()

// ════════════════════════════════════════════════════════════════
// 27. TENANT USER SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createTenantUserSchema = z.object({
  email: z.string().email('Invalid email format'),
  name: z.string().min(1, 'Name required'),
  role: z.enum([
    'tenant_admin',
    'operations_manager',
    'field_officer',
    'quality_controller',
    'trader',
    'finance_manager',
    'buyer',
    'viewer',
  ]),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  permissions: z.string().default('{}'),
  phone: z.string().optional(),
  avatar: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateTenantUserSchema = createTenantUserSchema.partial()

// ════════════════════════════════════════════════════════════════
// 28. PRODUCT MONITORING SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createProductMonitoringSchema = z.object({
  monitoringId: z.string().optional(),
  monitoringType: z.enum(['production_progress', 'on_site_verification', 'quality_check', 'shipment_monitoring']),
  productName: z.string().optional(),
  batchId: z.string().optional(),
  orderRef: z.string().optional(),
  factoryName: z.string().optional(),
  factoryAddress: z.string().optional(),
  country: z.string().optional(),
  scheduledDate: z.string().optional(),
  actualDate: z.string().optional(),
  inspectorName: z.string().optional(),
  status: z.enum(['scheduled', 'in_progress', 'completed', 'cancelled']).default('scheduled'),
  quantityOrdered: z.number().optional(),
  quantityProduced: z.number().optional(),
  quantityPassed: z.number().optional(),
  quantityFailed: z.number().optional(),
  packingStatus: z.enum(['conform', 'non_conform']).optional(),
  shippingMarkStatus: z.enum(['conform', 'non_conform']).optional(),
  labellingStatus: z.enum(['conform', 'non_conform']).optional(),
  findings: z.string().optional(),
  reportUrl: z.string().optional(),
  notes: z.string().optional(),
  amount: z.number().optional(),
  currency: z.string().optional(),
  paymentStatus: z.string().optional(),
  metadata: z.string().optional(),
  isActive: z.boolean().default(true),
})

export const updateProductMonitoringSchema = createProductMonitoringSchema.partial()

// ════════════════════════════════════════════════════════════════
// TYPE EXPORTS
// ════════════════════════════════════════════════════════════════

// Auth types
export type TenantLoginInput = z.infer<typeof tenantLoginSchema>
export type PlatformLoginInput = z.infer<typeof platformLoginSchema>
export type RegisterUserInput = z.infer<typeof registerUserSchema>

// Tenant types
export type CreateTenantInput = z.infer<typeof createTenantSchema>
export type UpdateTenantInput = z.infer<typeof updateTenantSchema>

// Platform user types
export type CreatePlatformUserInput = z.infer<typeof createPlatformUserSchema>
export type UpdatePlatformUserInput = z.infer<typeof updatePlatformUserSchema>

// Farmer types
export type CreateFarmerInput = z.infer<typeof createFarmerSchema>
export type UpdateFarmerInput = z.infer<typeof updateFarmerSchema>

// Farm land types
export type CreateFarmLandInput = z.infer<typeof createFarmLandSchema>
export type UpdateFarmLandInput = z.infer<typeof updateFarmLandSchema>

// Cultivation types
export type CreateCultivationInput = z.infer<typeof createCultivationSchema>
export type UpdateCultivationInput = z.infer<typeof updateCultivationSchema>

// Harvest traceability types
export type CreateHarvestTraceInput = z.infer<typeof createHarvestTraceSchema>
export type UpdateHarvestTraceInput = z.infer<typeof updateHarvestTraceSchema>

// 1. Nursery types
export type CreateNurseryInput = z.infer<typeof createNurserySchema>
export type UpdateNurseryInput = z.infer<typeof updateNurserySchema>

// 2. Land preparation types
export type CreateLandPreparationInput = z.infer<typeof createLandPreparationSchema>
export type UpdateLandPreparationInput = z.infer<typeof updateLandPreparationSchema>

// 3. Crop monitoring types
export type CreateCropMonitoringInput = z.infer<typeof createCropMonitoringSchema>
export type UpdateCropMonitoringInput = z.infer<typeof updateCropMonitoringSchema>

// 4. Fertilizer application types
export type CreateFertilizerAppInput = z.infer<typeof createFertilizerAppSchema>
export type UpdateFertilizerAppInput = z.infer<typeof updateFertilizerAppSchema>

// 5. Pest disease management types
export type CreatePestDiseaseInput = z.infer<typeof createPestDiseaseSchema>
export type UpdatePestDiseaseInput = z.infer<typeof updatePestDiseaseSchema>

// 6. Collection centre types
export type CreateCollectionCentreInput = z.infer<typeof createCollectionCentreSchema>
export type UpdateCollectionCentreInput = z.infer<typeof updateCollectionCentreSchema>

// 7. Procurement record types
export type CreateProcurementInput = z.infer<typeof createProcurementSchema>
export type UpdateProcurementInput = z.infer<typeof updateProcurementSchema>

// 8. Processing job order types
export type CreateProcessingJobInput = z.infer<typeof createProcessingJobSchema>
export type UpdateProcessingJobInput = z.infer<typeof updateProcessingJobSchema>

// 9. Cert assessment types
export type CreateCertAssessmentInput = z.infer<typeof createCertAssessmentSchema>
export type UpdateCertAssessmentInput = z.infer<typeof updateCertAssessmentSchema>

// 10. Coffee inspection types
export type CreateCoffeeInspectionInput = z.infer<typeof createCoffeeInspectionSchema>
export type UpdateCoffeeInspectionInput = z.infer<typeof updateCoffeeInspectionSchema>

// 11. Smart contract types
export type CreateSmartContractInput = z.infer<typeof createSmartContractSchema>
export type UpdateSmartContractInput = z.infer<typeof updateSmartContractSchema>

// 12. Marketplace listing types
export type CreateMarketplaceListingInput = z.infer<typeof createMarketplaceListingSchema>
export type UpdateMarketplaceListingInput = z.infer<typeof updateMarketplaceListingSchema>

// 13. EUDR compliance types
export type CreateEudrComplianceInput = z.infer<typeof createEudrComplianceSchema>
export type UpdateEudrComplianceInput = z.infer<typeof updateEudrComplianceSchema>

// 14. Deforestation assessment types
export type CreateDeforestationInput = z.infer<typeof createDeforestationSchema>
export type UpdateDeforestationInput = z.infer<typeof updateDeforestationSchema>

// 15. Export document types
export type CreateExportDocInput = z.infer<typeof createExportDocSchema>
export type UpdateExportDocInput = z.infer<typeof updateExportDocSchema>

// 16. Shipment types
export type CreateShipmentInput = z.infer<typeof createShipmentSchema>
export type UpdateShipmentInput = z.infer<typeof updateShipmentSchema>

// 17. Buyer types
export type CreateBuyerInput = z.infer<typeof createBuyerSchema>
export type UpdateBuyerInput = z.infer<typeof updateBuyerSchema>

// 18. Trading contract types
export type CreateTradingDeskInput = z.infer<typeof createTradingDeskSchema>
export type UpdateTradingDeskInput = z.infer<typeof updateTradingDeskSchema>

// 19. RFQ types
export type CreateRfqInput = z.infer<typeof createRfqSchema>
export type UpdateRfqInput = z.infer<typeof updateRfqSchema>

// 20. Logistics booking types
export type CreateLogisticsInput = z.infer<typeof createLogisticsSchema>
export type UpdateLogisticsInput = z.infer<typeof updateLogisticsSchema>

// 21. IoT sensor types
export type CreateIoTSensorInput = z.infer<typeof createIoTSensorSchema>
export type UpdateIoTSensorInput = z.infer<typeof updateIoTSensorSchema>

// 22. QC verification types
export type CreateQcVerificationInput = z.infer<typeof createQcVerificationSchema>
export type UpdateQcVerificationInput = z.infer<typeof updateQcVerificationSchema>

// 23. Tracking update types
export type CreateTrackingUpdateInput = z.infer<typeof createTrackingUpdateSchema>
export type UpdateTrackingUpdateInput = z.infer<typeof updateTrackingUpdateSchema>

// 24. Compliance booking types
export type CreateComplianceBookingInput = z.infer<typeof createComplianceBookingSchema>
export type UpdateComplianceBookingInput = z.infer<typeof updateComplianceBookingSchema>

// 25. Webhook endpoint types
export type CreateWebhookInput = z.infer<typeof createWebhookSchema>
export type UpdateWebhookInput = z.infer<typeof updateWebhookSchema>

// 26. API key types
export type CreateApiKeyInput = z.infer<typeof createApiKeySchema>
export type UpdateApiKeyInput = z.infer<typeof updateApiKeySchema>

// 27. Tenant user types
export type CreateTenantUserInput = z.infer<typeof createTenantUserSchema>
export type UpdateTenantUserInput = z.infer<typeof updateTenantUserSchema>

// 28. Product monitoring types
export type CreateProductMonitoringInput = z.infer<typeof createProductMonitoringSchema>
export type UpdateProductMonitoringInput = z.infer<typeof updateProductMonitoringSchema>

// ════════════════════════════════════════════════════════════════
// 29. ANALYTICS REPORT SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createAnalyticsReportSchema = z.object({
  reportType: z.string().min(1, 'Report type required'),
  title: z.string().min(1, 'Title required'),
  description: z.string().optional(),
  dateRangeStart: z.string().optional(),
  dateRangeEnd: z.string().optional(),
  parameters: z.any().optional(),
  format: z.enum(['json', 'csv', 'pdf']).default('json'),
  isScheduled: z.boolean().default(false),
  scheduleCron: z.string().optional(),
})

export const updateAnalyticsReportSchema = createAnalyticsReportSchema.partial()

// ════════════════════════════════════════════════════════════════
// 30. INSPECTION REQUEST SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createInspectionSchema = z.object({
  type: z.enum(['pre_shipment', 'during_production', 'final', 'spot_check']).optional(),
  inspectionLevel: z.string().optional(),
  commodity: z.string().optional(),
  quantity: z.number().optional(),
  supplier: z.string().optional(),
  inspector: z.string().optional(),
  date: z.string().optional(),
  country: z.string().optional(),
  location: z.string().optional(),
})

export const updateInspectionSchema = createInspectionSchema.partial()

// ════════════════════════════════════════════════════════════════
// 31. PLATFORM SETTING SCHEMAS
// ════════════════════════════════════════════════════════════════

export const createPlatformSettingSchema = z.object({
  category: z.string().min(1, 'Category required'),
  key: z.string().min(1, 'Key required'),
  value: z.string().min(0, 'Value required'),
  valueType: z.enum(['string', 'number', 'boolean', 'json']).default('string'),
  description: z.string().optional(),
  isPublic: z.boolean().default(false),
})

export const updatePlatformSettingSchema = z.object({
  category: z.string().min(1, 'Category required'),
  key: z.string().min(1, 'Key required'),
  value: z.string().optional(),
  description: z.string().optional(),
  isPublic: z.boolean().optional(),
})

// ════════════════════════════════════════════════════════════════
// 32. SELECT TENANT LOGIN SCHEMA
// ════════════════════════════════════════════════════════════════

export const selectTenantLoginSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(1, 'Password required'),
  tenantId: z.string().min(1, 'Tenant ID required'),
})

// Analytics report types
export type CreateAnalyticsReportInput = z.infer<typeof createAnalyticsReportSchema>
export type UpdateAnalyticsReportInput = z.infer<typeof updateAnalyticsReportSchema>

// Inspection types
export type CreateInspectionInput = z.infer<typeof createInspectionSchema>
export type UpdateInspectionInput = z.infer<typeof updateInspectionSchema>

// Platform setting types
export type CreatePlatformSettingInput = z.infer<typeof createPlatformSettingSchema>
export type UpdatePlatformSettingInput = z.infer<typeof updatePlatformSettingSchema>

// Select tenant login type
export type SelectTenantLoginInput = z.infer<typeof selectTenantLoginSchema>
