import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/price-tickers — List all tickers
// Query params: ?activeOnly=true (default) | false (show all)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const activeOnly = searchParams.get('activeOnly') !== 'false'

    const tickers = await db.priceTicker.findMany({
      where: activeOnly ? { isActive: true } : undefined,
      orderBy: [{ sortOrder: 'asc' }, { code: 'asc' }],
    })

    return NextResponse.json({ success: true, data: tickers })
  } catch (error) {
    console.error('Failed to fetch price tickers:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch price tickers' },
      { status: 500 }
    )
  }
}

// POST /api/price-tickers — Create a new ticker
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { code, name, exchange, unit, currency, basePrice, volatility, isActive, sortOrder } = body

    if (!code || !name || !exchange || basePrice === undefined || basePrice === null) {
      return NextResponse.json(
        { success: false, error: 'code, name, exchange, and basePrice are required' },
        { status: 400 }
      )
    }

    // Check if code already exists
    const existing = await db.priceTicker.findUnique({ where: { code } })
    if (existing) {
      return NextResponse.json(
        { success: false, error: `Ticker code "${code}" already exists` },
        { status: 409 }
      )
    }

    const ticker = await db.priceTicker.create({
      data: {
        code,
        name,
        exchange,
        unit: unit || 'USD/mt',
        currency: currency || 'USD',
        basePrice: parseFloat(basePrice),
        volatility: volatility !== undefined ? parseFloat(volatility) : 10,
        isActive: isActive !== undefined ? isActive : true,
        sortOrder: sortOrder !== undefined ? parseInt(sortOrder) : 0,
      },
    })

    return NextResponse.json({ success: true, data: ticker }, { status: 201 })
  } catch (error) {
    console.error('Failed to create price ticker:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create price ticker' },
      { status: 500 }
    )
  }
}
