import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/price-tickers/[id] — Get a single ticker
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const ticker = await db.priceTicker.findUnique({ where: { id } })

    if (!ticker) {
      return NextResponse.json(
        { success: false, error: 'Ticker not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, data: ticker })
  } catch (error) {
    console.error('Failed to fetch price ticker:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch price ticker' },
      { status: 500 }
    )
  }
}

// PUT /api/price-tickers/[id] — Update a ticker
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { code, name, exchange, unit, currency, basePrice, volatility, isActive, sortOrder } = body

    const existing = await db.priceTicker.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Ticker not found' },
        { status: 404 }
      )
    }

    // If code is being changed, check for uniqueness
    if (code && code !== existing.code) {
      const codeExists = await db.priceTicker.findUnique({ where: { code } })
      if (codeExists) {
        return NextResponse.json(
          { success: false, error: `Ticker code "${code}" already exists` },
          { status: 409 }
        )
      }
    }

    const ticker = await db.priceTicker.update({
      where: { id },
      data: {
        ...(code !== undefined && { code }),
        ...(name !== undefined && { name }),
        ...(exchange !== undefined && { exchange }),
        ...(unit !== undefined && { unit }),
        ...(currency !== undefined && { currency }),
        ...(basePrice !== undefined && { basePrice: parseFloat(basePrice) }),
        ...(volatility !== undefined && { volatility: parseFloat(volatility) }),
        ...(isActive !== undefined && { isActive }),
        ...(sortOrder !== undefined && { sortOrder: parseInt(sortOrder) }),
      },
    })

    return NextResponse.json({ success: true, data: ticker })
  } catch (error) {
    console.error('Failed to update price ticker:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update price ticker' },
      { status: 500 }
    )
  }
}

// DELETE /api/price-tickers/[id] — Delete a ticker
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const existing = await db.priceTicker.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Ticker not found' },
        { status: 404 }
      )
    }

    await db.priceTicker.delete({ where: { id } })

    return NextResponse.json({ success: true, message: 'Ticker deleted' })
  } catch (error) {
    console.error('Failed to delete price ticker:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete price ticker' },
      { status: 500 }
    )
  }
}
