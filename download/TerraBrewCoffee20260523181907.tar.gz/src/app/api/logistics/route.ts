import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { createLogisticsSchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'logistics', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)
    const url = new URL(req.url)
    const status = url.searchParams.get('status') || undefined

    const where: any = { tenantId, isActive: true }
    if (status) where.status = status
    if (search) {
      where.OR = [
        { shipmentId: { contains: search } },
        { vesselName: { contains: search } },
        { containerNumber: { contains: search } },
        { bookingNumber: { contains: search } },
        { freightForwarder: { contains: search } },
        { customsBroker: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.shipment.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          buyer: { select: { id: true, companyName: true, buyerCode: true, country: true } },
          trackingUpdates: {
            where: { isActive: true },
            orderBy: { timestamp: 'desc' },
            take: 5,
          },
          iotSensors: {
            where: { isActive: true },
            select: {
              id: true,
              sensorType: true,
              deviceId: true,
              deviceName: true,
              lastReading: true,
              lastReadingAt: true,
              batteryLevel: true,
            },
          },
          exportDocuments: {
            where: { isActive: true },
            select: { id: true, documentType: true, status: true },
          },
          _count: { select: { trackingUpdates: true, iotSensors: true } },
        },
      }),
      db.shipment.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'logistics', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const validation = validateBody(createLogisticsSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data
    const tenantId = user!.tenantId!

    // Create a shipment with logistics-specific defaults
    // validatedData contains logistics-schema fields; body may have extra shipment fields
    const item = await db.shipment.create({
      data: {
        tenantId,
        createdBy: user!.id,
        shipmentId: body.shipmentId,
        status: validatedData.bookingStatus || 'planned',
        originCountry: validatedData.originCountry,
        destinationCountry: validatedData.destinationCountry,
        portOfLoading: validatedData.originPort,
        portOfDischarge: validatedData.destinationPort,
        vesselName: validatedData.vesselName,
        vesselImo: body.vesselImo,
        containerNumber: body.containerNumber,
        bookingNumber: body.bookingNumber,
        billOfLadingNumber: validatedData.blNumber,
        estimatedDeparture: validatedData.etd ? new Date(validatedData.etd) : null,
        actualDeparture: validatedData.atd ? new Date(validatedData.atd) : null,
        estimatedArrival: validatedData.eta ? new Date(validatedData.eta) : null,
        actualArrival: validatedData.ata ? new Date(validatedData.ata) : null,
        totalWeightKg: validatedData.totalWeightKg,
        totalBags: body.totalBags,
        commodity: validatedData.commodity || 'coffee',
        grade: body.grade,
        contractReference: body.contractReference,
        freightForwarder: body.freightForwarder,
        customsBroker: body.customsBroker,
        shippingLine: validatedData.shippingLine,
        trackingUrl: validatedData.trackingUrl,
        notes: validatedData.notes,
        metadata: validatedData.metadata ? JSON.stringify(validatedData.metadata) : null,
        buyerId: body.buyerId,
      },
      include: {
        buyer: { select: { id: true, companyName: true } },
      },
    })

    if (validatedData.originCountry || validatedData.originPort) {
      await db.trackingUpdate.create({
        data: {
          tenantId,
          shipmentId: item.id,
          updateType: 'departure',
          location: validatedData.originPort || validatedData.originCountry,
          description: `Logistics entry created — origin: ${validatedData.originCountry || 'N/A'}`,
          reportedBy: user!.id,
        },
      })
    }

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
