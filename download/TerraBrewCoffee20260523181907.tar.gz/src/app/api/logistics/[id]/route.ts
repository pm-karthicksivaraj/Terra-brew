import { getAuthUser, requireTenantAccess, apiResponse, apiError, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { updateLogisticsSchema } from '@/lib/validators'

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request)
  const authError = requireTenantAccess(user, 'logistics', 'read')
  if (authError) return authError

  try {
    const { id } = await params
    const item = await db.shipment.findFirst({
      where: { id, tenantId: user!.tenantId!, isActive: true },
      include: {
        buyer: { select: { id: true, companyName: true, buyerCode: true, country: true, email: true, phone: true } },
        trackingUpdates: {
          where: { isActive: true },
          orderBy: { timestamp: 'desc' },
        },
        iotSensors: {
          where: { isActive: true },
          include: {
            readings: {
              orderBy: { timestamp: 'desc' },
              take: 10,
            },
          },
        },
        exportDocuments: {
          where: { isActive: true },
        },
      },
    })
    if (!item) return apiError('Logistics entry not found', 404)
    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request)
  const authError = requireTenantAccess(user, 'logistics', 'update')
  if (authError) return authError

  try {
    const { id } = await params
    const body = await request.json()

    const validation = validateBody(updateLogisticsSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    const existing = await db.shipment.findFirst({
      where: { id, tenantId: user!.tenantId!, isActive: true },
    })
    if (!existing) return apiError('Logistics entry not found', 404)

    // Build update data, converting date strings to Date objects
    const updateData: any = { ...validatedData }
    // Map logistics-specific fields to shipment fields
    if (validatedData.originPort) updateData.portOfLoading = validatedData.originPort
    if (validatedData.destinationPort) updateData.portOfDischarge = validatedData.destinationPort
    if (validatedData.blNumber) updateData.billOfLadingNumber = validatedData.blNumber
    if (validatedData.etd) updateData.estimatedDeparture = new Date(validatedData.etd)
    if (validatedData.atd) updateData.actualDeparture = new Date(validatedData.atd)
    if (validatedData.eta) updateData.estimatedArrival = new Date(validatedData.eta)
    if (validatedData.ata) updateData.actualArrival = new Date(validatedData.ata)
    if (validatedData.bookingStatus) updateData.status = validatedData.bookingStatus
    // Remove logistics-specific fields that don't exist on Shipment model
    delete updateData.bookingId
    delete updateData.bookingType
    delete updateData.originPort
    delete updateData.destinationPort
    delete updateData.commodityCategory
    delete updateData.totalVolumeCbm
    delete updateData.containerType
    delete updateData.containerCount
    delete updateData.voyageNumber
    delete updateData.etd
    delete updateData.atd
    delete updateData.eta
    delete updateData.ata
    delete updateData.freightRate
    delete updateData.freightType
    delete updateData.incoterms
    delete updateData.bookingStatus
    delete updateData.blNumber

    const dateFields = [
      'estimatedDeparture', 'actualDeparture', 'estimatedArrival', 'actualArrival',
    ]
    for (const field of dateFields) {
      if (validatedData[field as keyof typeof validatedData] && !updateData[field]) {
        updateData[field] = new Date(validatedData[field as keyof typeof validatedData] as string)
      }
    }

    if (validatedData.bookingStatus && validatedData.bookingStatus !== existing.status) {
      const updateTypeMap: Record<string, string> = {
        booked: 'departure',
        in_transit: 'departure',
        arrived: 'arrival',
        delivered: 'delivery',
        cancelled: 'customs',
      }

      await db.trackingUpdate.create({
        data: {
          tenantId: user!.tenantId!,
          shipmentId: id,
          updateType: updateTypeMap[validatedData.bookingStatus] || 'customs',
          location: validatedData.destinationPort || existing.portOfDischarge || undefined,
          description: `Status updated from ${existing.status} to ${validatedData.bookingStatus}`,
          reportedBy: user!.id,
        },
      })
    }

    const item = await db.shipment.update({
      where: { id },
      data: updateData,
    })
    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
