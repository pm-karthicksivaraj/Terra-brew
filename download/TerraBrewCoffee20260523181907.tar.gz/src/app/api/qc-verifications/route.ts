import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { createQcVerificationSchema, updateQcVerificationSchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'qc-verification', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)
    const url = new URL(req.url)
    const verificationType = url.searchParams.get('verificationType') || undefined
    const status = url.searchParams.get('status') || undefined

    const where: any = { tenantId, isActive: true }
    if (verificationType) where.verificationType = verificationType
    if (status) where.status = status
    if (search) {
      where.OR = [
        { inspectorName: { contains: search } },
        { inspectorCertNo: { contains: search } },
        { notes: { contains: search } },
        { entityId: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.qcVerification.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.qcVerification.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'qc-verification', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const validation = validateBody(createQcVerificationSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data
    const tenantId = user!.tenantId!

    const item = await db.qcVerification.create({
      data: {
        ...validatedData,
        tenantId,
      },
    })

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
