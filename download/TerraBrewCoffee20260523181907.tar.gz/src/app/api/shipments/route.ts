import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { writeAuditLog } from '@/lib/audit'
import { createShipmentSchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'shipments', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)
    const url = new URL(req.url)
    const status = url.searchParams.get('status') || undefined

    const where: any = { tenantId, isActive: true }
    if (status) where.status = status
    if (search) {
      where.OR = [
        { shipmentId: { contains: search } },
        { vesselName: { contains: search } },
        { containerNumber: { contains: search } },
        { bookingNumber: { contains: search } },
        { billOfLadingNumber: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.shipment.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          buyer: { select: { id: true, companyName: true, buyerCode: true } },
          _count: { select: { exportDocuments: true, trackingUpdates: true, iotSensors: true } },
        },
      }),
      db.shipment.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'shipments', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const validation = validateBody(createShipmentSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data
    const tenantId = user!.tenantId!

    const item = await db.shipment.create({
      data: {
        ...validatedData,
        tenantId,
        createdBy: user!.id,
      },
    })

    await writeAuditLog({
      tenantId,
      userId: user!.id,
      action: 'create',
      entity: 'Shipment',
      entityId: item.id,
      details: `Created Shipment: ${item.shipmentId || item.id}`,
      req,
    })

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
