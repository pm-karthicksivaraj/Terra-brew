import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser, requireAuth, requirePlatformAdmin, apiResponse } from '@/lib/api-middleware'

export async function GET(request: NextRequest) {
  const user = await getAuthUser(request)
  const authError = requireAuth(user)
  if (authError) return authError

  // Platform admins can see all modules
  if (user!.isPlatformAdmin) {
    const modules = await db.module.findMany({ orderBy: { category: 'asc' } })
    return apiResponse({ modules, enabledSlugs: null })
  }

  // Tenant users: return enabled module slugs for their tenant
  if (!user!.tenantId) {
    return NextResponse.json({ success: false, error: 'Tenant context required' }, { status: 403 })
  }

  const tenantModules = await db.tenantModule.findMany({
    where: { tenantId: user!.tenantId, isEnabled: true },
    select: { moduleSlug: true },
  })

  const enabledSlugs = tenantModules.map((tm: { moduleSlug: string }) => tm.moduleSlug)

  return apiResponse({ modules: [], enabledSlugs })
}
