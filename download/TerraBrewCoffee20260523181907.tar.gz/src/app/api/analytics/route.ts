import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { createAnalyticsReportSchema } from '@/lib/validators'
import { db } from '@/lib/db'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'analytics', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)
    const url = new URL(req.url)
    const reportType = url.searchParams.get('reportType') || undefined
    const status = url.searchParams.get('status') || undefined

    const where: any = { tenantId, isActive: true }
    if (reportType) where.reportType = reportType
    if (status) where.status = status
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.analyticsReport.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.analyticsReport.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'analytics', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const tenantId = user!.tenantId!

    const validation = validateBody(createAnalyticsReportSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    // Create report in generating status
    const item = await db.analyticsReport.create({
      data: {
        reportType: validatedData.reportType,
        title: validatedData.title,
        description: validatedData.description,
        dateRangeStart: validatedData.dateRangeStart ? new Date(validatedData.dateRangeStart) : null,
        dateRangeEnd: validatedData.dateRangeEnd ? new Date(validatedData.dateRangeEnd) : null,
        parameters: validatedData.parameters ? JSON.stringify(validatedData.parameters) : null,
        format: validatedData.format,
        status: 'generating',
        isScheduled: validatedData.isScheduled,
        scheduleCron: validatedData.scheduleCron || null,
        tenantId,
        createdBy: user!.id,
      },
    })

    // In production, trigger async report generation here
    // For now, immediately mark as ready with placeholder data
    const generatedReport = await db.analyticsReport.update({
      where: { id: item.id },
      data: {
        status: 'ready',
        data: JSON.stringify({ message: 'Report generated successfully', generatedAt: new Date().toISOString() }),
        lastGeneratedAt: new Date(),
      },
    })

    return apiResponse(generatedReport, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
