import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { writeAuditLog } from '@/lib/audit'
import { createExportDocSchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'export-docs', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)
    const url = new URL(req.url)
    const documentType = url.searchParams.get('documentType') || undefined
    const status = url.searchParams.get('status') || undefined

    const where: any = { tenantId, isActive: true }
    if (documentType) where.documentType = documentType
    if (status) where.status = status
    if (search) {
      where.OR = [
        { documentNumber: { contains: search } },
        { issuingAuthority: { contains: search } },
        { notes: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.exportDocument.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          shipment: { select: { id: true, shipmentId: true, status: true } },
        },
      }),
      db.exportDocument.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'export-docs', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const validation = validateBody(createExportDocSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data
    const tenantId = user!.tenantId!

    const item = await db.exportDocument.create({
      data: {
        ...validatedData,
        tenantId,
        createdBy: user!.id,
      },
    })

    await writeAuditLog({
      tenantId,
      userId: user!.id,
      action: 'create',
      entity: 'ExportDocument',
      entityId: item.id,
      details: `Created ExportDocument: ${item.documentNumber || item.id}`,
      req,
    })

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
