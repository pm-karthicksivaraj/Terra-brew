import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { createHarvestTraceSchema, updateHarvestTraceSchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'harvest-traceabilities', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const url = new URL(req.url)
    const idParam = url.searchParams.get('id')

    // Single-item fetch by ID
    if (idParam) {
      const item = await db.harvestTraceability.findFirst({
        where: { id: idParam, tenantId, isActive: true },
        include: {
          farmer: { select: { id: true, fullName: true, farmerCode: true, province: true, contactNumber: true } },
          farmLand: { select: { id: true, farmName: true, plotBlockId: true, totalLandHolding: true, altitude: true } },
        },
      })
      if (!item) return apiError('Harvest traceability record not found', 404)
      return apiResponse({ data: item })
    }

    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)

    const batchIdFilter = url.searchParams.get('batchId')

    const where: any = { tenantId, isActive: true }
    if (search) {
      where.OR = [
        { coffeeVariety: { contains: search } },
        { batchId: { contains: search } },
        { processingMethod: { contains: search } },
        { harvestMethod: { contains: search } },
      ]
    }
    // Support batchId filter
    if (batchIdFilter) {
      where.batchId = batchIdFilter
    }

    const [items, total] = await Promise.all([
      db.harvestTraceability.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          farmer: { select: { id: true, fullName: true, farmerCode: true } },
          farmLand: { select: { id: true, farmName: true, plotBlockId: true } },
        },
      }),
      db.harvestTraceability.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'harvest-traceabilities', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const tenantId = user!.tenantId!

    const validation = validateBody(createHarvestTraceSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    const item = await db.harvestTraceability.create({
      data: {
        ...validatedData,
        tenantId,
        createdBy: user!.id,
      },
    })

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function PUT(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'harvest-traceabilities', 'update')
  if (authError) return authError

  try {
    const body = await req.json()
    const { id, ...rest } = body
    if (!id) return apiError('ID is required', 400)

    const validation = validateBody(updateHarvestTraceSchema, rest)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    const existing = await db.harvestTraceability.findFirst({ where: { id, tenantId: user!.tenantId!, isActive: true } })
    if (!existing) return apiError('Harvest traceability record not found', 404)

    const item = await db.harvestTraceability.update({
      where: { id },
      data: validatedData,
    })

    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function DELETE(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'harvest-traceabilities', 'delete')
  if (authError) return authError

  try {
    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')
    if (!id) return apiError('ID is required', 400)

    const existing = await db.harvestTraceability.findFirst({ where: { id, tenantId: user!.tenantId!, isActive: true } })
    if (!existing) return apiError('Harvest traceability record not found', 404)

    const item = await db.harvestTraceability.update({
      where: { id },
      data: { isActive: false },
    })

    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
