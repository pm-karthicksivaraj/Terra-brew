import { getAuthUser, requireTenantAccess, apiResponse, apiError, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { updateIoTSensorSchema } from '@/lib/validators'

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request)
  const authError = requireTenantAccess(user, 'iot-tracking', 'read')
  if (authError) return authError

  try {
    const { id } = await params
    const item = await db.ioTSensor.findFirst({
      where: { id, tenantId: user!.tenantId!, isActive: true },
      include: {
        shipment: { select: { id: true, shipmentId: true, status: true } },
        _count: { select: { readings: true } },
      },
    })
    if (!item) return apiError('IoT sensor not found', 404)
    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request)
  const authError = requireTenantAccess(user, 'iot-tracking', 'update')
  if (authError) return authError

  try {
    const { id } = await params
    const body = await request.json()

    const validation = validateBody(updateIoTSensorSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    const existing = await db.ioTSensor.findFirst({
      where: { id, tenantId: user!.tenantId!, isActive: true },
    })
    if (!existing) return apiError('IoT sensor not found', 404)

    const item = await db.ioTSensor.update({
      where: { id },
      data: validatedData,
    })
    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request)
  const authError = requireTenantAccess(user, 'iot-tracking', 'delete')
  if (authError) return authError

  try {
    const { id } = await params
    const existing = await db.ioTSensor.findFirst({
      where: { id, tenantId: user!.tenantId!, isActive: true },
    })
    if (!existing) return apiError('IoT sensor not found', 404)

    const item = await db.ioTSensor.update({
      where: { id },
      data: { isActive: false },
    })
    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
