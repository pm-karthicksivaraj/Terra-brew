import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { z } from 'zod'

// Inline schema for IoT sensor reading input
const createIoTReadingSchema = z.object({
  readingType: z.string().min(1, 'Reading type required'),
  value: z.number(),
  unit: z.string().min(1, 'Unit required'),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  isAlert: z.boolean().default(false),
  alertType: z.string().optional(),
  timestamp: z.string().optional(),
  batteryLevel: z.number().optional(),
})

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request)
  const authError = requireTenantAccess(user, 'iot-tracking', 'read')
  if (authError) return authError

  try {
    const { id } = await params
    // Verify sensor belongs to tenant
    const sensor = await db.ioTSensor.findFirst({
      where: { id, tenantId: user!.tenantId!, isActive: true },
    })
    if (!sensor) return apiError('IoT sensor not found', 404)

    const { page, pageSize, sortBy, sortOrder } = getPaginationParams(request as any)
    const url = new URL(request.url)
    const readingType = url.searchParams.get('readingType') || undefined
    const isAlert = url.searchParams.get('isAlert')

    const where: any = { sensorId: id }
    if (readingType) where.readingType = readingType
    if (isAlert !== null && isAlert !== undefined) {
      where.isAlert = isAlert === 'true'
    }

    const [items, total] = await Promise.all([
      db.ioTReading.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.ioTReading.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request)
  const authError = requireTenantAccess(user, 'iot-tracking', 'create')
  if (authError) return authError

  try {
    const { id } = await params
    const body = await request.json()

    const validation = validateBody(createIoTReadingSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    // Verify sensor belongs to tenant
    const sensor = await db.ioTSensor.findFirst({
      where: { id, tenantId: user!.tenantId!, isActive: true },
    })
    if (!sensor) return apiError('IoT sensor not found', 404)

    const reading = await db.ioTReading.create({
      data: {
        sensorId: id,
        readingType: validatedData.readingType,
        value: validatedData.value,
        unit: validatedData.unit,
        latitude: validatedData.latitude,
        longitude: validatedData.longitude,
        isAlert: validatedData.isAlert || false,
        alertType: validatedData.alertType,
        timestamp: validatedData.timestamp ? new Date(validatedData.timestamp) : new Date(),
      },
    })

    // Update sensor's last reading
    await db.ioTSensor.update({
      where: { id },
      data: {
        lastReading: JSON.stringify({ readingType: validatedData.readingType, value: validatedData.value, unit: validatedData.unit }),
        lastReadingAt: new Date(),
        batteryLevel: validatedData.batteryLevel ?? sensor.batteryLevel,
      },
    })

    return apiResponse(reading, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
