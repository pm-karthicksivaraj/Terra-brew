import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { createIoTSensorSchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'iot-tracking', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)
    const url = new URL(req.url)
    const sensorType = url.searchParams.get('sensorType') || undefined
    const shipmentId = url.searchParams.get('shipmentId') || undefined

    const where: any = { tenantId, isActive: true }
    if (sensorType) where.sensorType = sensorType
    if (shipmentId) where.shipmentId = shipmentId
    if (search) {
      where.OR = [
        { deviceId: { contains: search } },
        { deviceName: { contains: search } },
        { manufacturer: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.ioTSensor.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          shipment: { select: { id: true, shipmentId: true, status: true } },
          _count: { select: { readings: true } },
        },
      }),
      db.ioTSensor.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'iot-tracking', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const validation = validateBody(createIoTSensorSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data
    const tenantId = user!.tenantId!

    // Verify shipment if provided
    if (validatedData.shipmentId) {
      const shipment = await db.shipment.findFirst({
        where: { id: validatedData.shipmentId, tenantId, isActive: true },
      })
      if (!shipment) return apiError('Shipment not found', 404)
    }

    const item = await db.ioTSensor.create({
      data: {
        ...validatedData,
        tenantId,
      },
    })

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
