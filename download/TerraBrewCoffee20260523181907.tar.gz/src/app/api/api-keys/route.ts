import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import crypto from 'crypto'
import { z } from 'zod'

// Inline schema for API key input (permissions as optional any, auto-generates key)
const createApiKeyInputSchema = z.object({
  name: z.string().min(1, 'Name required'),
  permissions: z.any().optional(),
  tier: z.enum(['starter', 'professional', 'enterprise']).default('starter'),
  rateLimitPerMin: z.number().int().positive().default(60),
  expiresAt: z.string().optional(),
  isActive: z.boolean().default(true),
})

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'api-access', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, sortBy, sortOrder } = getPaginationParams(req as any)

    const where: any = { tenantId, isActive: true }

    const [items, total] = await Promise.all([
      db.apiKey.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true,
          name: true,
          keyPrefix: true,
          permissions: true,
          tier: true,
          rateLimitPerMin: true,
          lastUsedAt: true,
          expiresAt: true,
          isActive: true,
          createdAt: true,
          updatedAt: true,
        },
      }),
      db.apiKey.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'api-access', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const validation = validateBody(createApiKeyInputSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data
    const tenantId = user!.tenantId!

    // Generate API key
    const rawKey = `tb_${crypto.randomBytes(24).toString('hex')}`
    const keyHash = crypto.createHash('sha256').update(rawKey).digest('hex')
    const keyPrefix = rawKey.substring(0, 8)

    const item = await db.apiKey.create({
      data: {
        name: validatedData.name,
        keyHash,
        keyPrefix,
        permissions: validatedData.permissions ? JSON.stringify(validatedData.permissions) : '[]',
        tier: validatedData.tier || 'starter',
        rateLimitPerMin: validatedData.rateLimitPerMin || 60,
        expiresAt: validatedData.expiresAt ? new Date(validatedData.expiresAt) : null,
        tenantId,
        createdBy: user!.id,
      },
    })

    // Return the raw key only once — it cannot be retrieved later
    return apiResponse({
      id: item.id,
      name: item.name,
      key: rawKey,
      keyPrefix: item.keyPrefix,
      tier: item.tier,
      rateLimitPerMin: item.rateLimitPerMin,
      expiresAt: item.expiresAt,
      createdAt: item.createdAt,
    }, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
