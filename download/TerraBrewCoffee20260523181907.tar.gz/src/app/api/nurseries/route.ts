import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { createNurserySchema, updateNurserySchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'nurseries', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const url = new URL(req.url)
    const idParam = url.searchParams.get('id')

    if (idParam) {
      const item = await db.nursery.findFirst({
        where: { id: idParam, tenantId, isActive: true },
        include: {
          farmer: { select: { id: true, fullName: true, farmerCode: true } },
        },
      })
      if (!item) return apiError('Nursery not found', 404)
      return apiResponse({ data: item })
    }

    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)

    const where: any = { tenantId, isActive: true }
    if (search) {
      where.OR = [
        { nurseryName: { contains: search } },
        { nurseryCode: { contains: search } },
        { location: { contains: search } },
        { species: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.nursery.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          farmer: { select: { id: true, fullName: true, farmerCode: true } },
        },
      }),
      db.nursery.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'nurseries', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const tenantId = user!.tenantId!

    const validation = validateBody(createNurserySchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    const item = await db.nursery.create({
      data: {
        ...validatedData,
        tenantId,
        createdBy: user!.id,
      },
    })

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function PUT(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'nurseries', 'update')
  if (authError) return authError

  try {
    const body = await req.json()
    const { id, ...rest } = body
    if (!id) return apiError('ID is required', 400)

    const validation = validateBody(updateNurserySchema, rest)
    if ('error' in validation) return validation.error
    const validatedData = validation.data

    const existing = await db.nursery.findFirst({ where: { id, tenantId: user!.tenantId!, isActive: true } })
    if (!existing) return apiError('Nursery not found', 404)

    const item = await db.nursery.update({
      where: { id },
      data: validatedData,
    })

    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function DELETE(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'nurseries', 'delete')
  if (authError) return authError

  try {
    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')
    if (!id) return apiError('ID is required', 400)

    const existing = await db.nursery.findFirst({ where: { id, tenantId: user!.tenantId!, isActive: true } })
    if (!existing) return apiError('Nursery not found', 404)

    const item = await db.nursery.update({
      where: { id },
      data: { isActive: false },
    })

    return apiResponse(item)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
