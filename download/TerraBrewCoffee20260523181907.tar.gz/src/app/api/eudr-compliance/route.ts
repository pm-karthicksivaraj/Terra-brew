import { getAuthUser, requireTenantAccess, apiResponse, apiError, getPaginationParams, validateBody } from '@/lib/api-middleware'
import { db } from '@/lib/db'
import { writeAuditLog } from '@/lib/audit'
import { createEudrComplianceSchema } from '@/lib/validators'

export async function GET(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'eudr-compliance', 'read')
  if (authError) return authError

  try {
    const tenantId = user!.tenantId!
    const { page, pageSize, search, sortBy, sortOrder } = getPaginationParams(req as any)
    const url = new URL(req.url)
    const status = url.searchParams.get('status') || undefined
    const riskLevel = url.searchParams.get('riskLevel') || undefined

    const where: any = { tenantId, isActive: true }
    if (status) where.status = status
    if (riskLevel) where.riskLevel = riskLevel
    if (search) {
      where.OR = [
        { complianceId: { contains: search } },
        { batchId: { contains: search } },
        { notes: { contains: search } },
      ]
    }

    const [items, total] = await Promise.all([
      db.eudrCompliance.findMany({
        where,
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          farmer: { select: { id: true, fullName: true, farmerCode: true } },
          farmLand: { select: { id: true, farmName: true } },
        },
      }),
      db.eudrCompliance.count({ where }),
    ])

    return apiResponse({ data: items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}

export async function POST(req: Request) {
  const user = await getAuthUser(req)
  const authError = requireTenantAccess(user, 'eudr-compliance', 'create')
  if (authError) return authError

  try {
    const body = await req.json()
    const validation = validateBody(createEudrComplianceSchema, body)
    if ('error' in validation) return validation.error
    const validatedData = validation.data
    const tenantId = user!.tenantId!

    const item = await db.eudrCompliance.create({
      data: {
        ...validatedData,
        tenantId,
        createdBy: user!.id,
      },
    })

    await writeAuditLog({
      tenantId,
      userId: user!.id,
      action: 'create',
      entity: 'EudrCompliance',
      entityId: item.id,
      details: `Created EUDR Compliance: ${item.complianceId || item.id}`,
      req,
    })

    return apiResponse(item, 201)
  } catch (e: any) {
    return apiError(e.message, 500)
  }
}
