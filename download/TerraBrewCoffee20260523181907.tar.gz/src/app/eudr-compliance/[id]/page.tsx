'use client'

import { useState, useMemo } from 'react'
import { useRouter, useParams, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { DashboardShell } from '@/components/layout/dashboard-shell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Shield, AlertTriangle, CheckCircle2, Clock, ChevronLeft,
  FileCheck, MapPin, Satellite, TreePine, FileText,
  CalendarDays, Target, Layers, ExternalLink, Send,
  Pencil, ArrowLeft, Activity
} from 'lucide-react'
import { FadeIn } from '@/components/ui/motion'
import { GeoLocationMap } from '@/components/map'
import {
  STATUS_COLORS, RISK_COLORS, DDS_STATUS_COLORS,
  getRiskScoreColor, getRiskBarColor,
  getRecordById, getAssessmentsForRecord, getDDSForComplianceId,
  type DeforestationAssessment, type DDSRecord,
} from '../_lib/data'

// ─── Helper ──────────────────────────────────────────────────────

function getRiskScoreColorVal(score?: number): string {
  if (!score) return 'text-gray-500'
  if (score > 70) return 'text-red-600'
  if (score > 40) return 'text-yellow-600'
  return 'text-green-600'
}

function getRiskBarColorVal(score?: number): string {
  if (!score) return 'bg-gray-300'
  if (score > 70) return 'bg-red-500'
  if (score > 40) return 'bg-yellow-500'
  return 'bg-green-500'
}

const WIZARD_STEPS = ['Basic Info', 'Geolocation & Land', 'Risk Assessment', 'Verification & DDS', 'Validity & Notes']

// ─── Overview Tab for Detail ─────────────────────────────────────

function DetailOverviewTab({ record }: { record: any }) {
  return (
    <div className="space-y-6">
      {/* Status & Risk */}
      <FadeIn>
        <div className="flex items-center gap-3">
          <Badge className={`${STATUS_COLORS[record.status]} border capitalize`}>{record.status?.replace('_', ' ')}</Badge>
          <Badge className={`${RISK_COLORS[record.riskLevel]} border capitalize`}>{record.riskLevel} Risk</Badge>
          {record.deforestationRiskScore != null && (
            <span className={`font-mono font-bold text-sm ${getRiskScoreColor(record.deforestationRiskScore)}`}>
              Score: {record.deforestationRiskScore}/100
            </span>
          )}
        </div>
      </FadeIn>

      {/* Risk Score Bar */}
      {record.deforestationRiskScore != null && (
        <FadeIn delay={0.05}>
          <div className="space-y-1">
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div className={`h-full rounded-full ${getRiskBarColor(record.deforestationRiskScore)}`} style={{ width: `${Math.min(record.deforestationRiskScore, 100)}%` }} />
            </div>
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>Low (0-40)</span><span>Medium (41-70)</span><span>High (71-100)</span>
            </div>
          </div>
        </FadeIn>
      )}

      {/* Core Info */}
      <FadeIn delay={0.1}>
        <Card className="rounded-xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Shield className="w-4 h-4" /> Core Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
              <div><span className="text-muted-foreground text-xs">Compliance ID</span><p className="font-mono text-xs font-bold">{record.complianceId}</p></div>
              <div><span className="text-muted-foreground text-xs">Batch ID</span><p className="font-mono text-xs">{record.batchId || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Farmer</span><p className="text-xs">{record.farmer?.name || record.farmerId || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Farm Land</span><p className="text-xs">{record.farmLand?.farmName || record.farmLandId || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Land Use Type</span><p className="text-xs capitalize">{record.landUseType?.replace('_', ' ') || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Created</span><p className="text-xs">{new Date(record.createdAt).toLocaleDateString()}</p></div>
            </div>
          </CardContent>
        </Card>
      </FadeIn>

      {/* Geolocation with Map */}
      <FadeIn delay={0.15}>
        <Card className="rounded-xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <MapPin className="w-4 h-4" /> Geolocation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-muted-foreground text-xs">Latitude</span><p className="font-mono text-xs">{record.geolocationLat ?? '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Longitude</span><p className="font-mono text-xs">{record.geolocationLng ?? '—'}</p></div>
            </div>
            {record.geolocationLat && record.geolocationLng ? (
              <GeoLocationMap
                lat={record.geolocationLat}
                lng={record.geolocationLng}
                height="350px"
                popupText={`${record.complianceId} — ${record.farmLand?.farmName || record.farmLandId || 'Farm Location'}`}
              />
            ) : (
              <div className="h-[200px] bg-muted/30 rounded-lg flex items-center justify-center border border-dashed border-muted-foreground/20">
                <p className="text-xs text-muted-foreground">No geolocation data available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </FadeIn>

      {/* Verification & DDS */}
      <FadeIn delay={0.2}>
        <Card className="rounded-xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <FileCheck className="w-4 h-4" /> Verification & DDS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-muted-foreground text-xs">Verification Date</span><p className="text-xs">{record.verificationDate ? new Date(record.verificationDate).toLocaleDateString() : '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Verified By</span><p className="text-xs">{record.verifiedBy || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">DDS Document</span><p className="font-mono text-xs">{record.dueDiligenceStatement || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">TRACES Certificate</span><p className="font-mono text-xs">{record.tracesCertificateRef || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Satellite Imagery</span><p className="font-mono text-xs">{record.satelliteImageryRef || '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Land Cover Change</span><p className="text-xs">{record.landCoverChangeDate ? new Date(record.landCoverChangeDate).toLocaleDateString() : '—'}</p></div>
            </div>
          </CardContent>
        </Card>
      </FadeIn>

      {/* Validity & Notes */}
      <FadeIn delay={0.25}>
        <Card className="rounded-xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Validity & Notes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-muted-foreground text-xs">Valid From</span><p className="text-xs">{record.validFrom ? new Date(record.validFrom).toLocaleDateString() : '—'}</p></div>
              <div><span className="text-muted-foreground text-xs">Valid Until</span><p className="text-xs">{record.validUntil ? new Date(record.validUntil).toLocaleDateString() : '—'}</p></div>
            </div>
            {record.notes && (
              <div><span className="text-muted-foreground text-xs">Notes</span><p className="mt-1 p-3 bg-muted rounded-lg text-xs">{record.notes}</p></div>
            )}
            {record.metadata && (
              <div><span className="text-muted-foreground text-xs">Metadata</span><pre className="mt-1 p-3 bg-muted rounded-lg text-[10px] font-mono overflow-auto">{JSON.stringify(record.metadata, null, 2)}</pre></div>
            )}
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  )
}

// ─── Deforestation Assessment Tab for Detail ─────────────────────

function DetailDeforestationTab({ assessments }: { assessments: DeforestationAssessment[] }) {
  if (assessments.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
        <Satellite className="w-12 h-12 mb-3 opacity-30" />
        <p className="text-sm">No deforestation assessments found for this record</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {assessments.map((item) => (
        <FadeIn key={item.id}>
          <Card className="rounded-xl">
            <CardContent className="p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge className={`${RISK_COLORS[item.riskCategory] || ''} border capitalize text-xs`}>{item.riskCategory} Risk</Badge>
                  {item.deforestationDetected ? (
                    <Badge className="bg-red-100 text-red-800 border text-[10px]">⚠ Deforestation Detected</Badge>
                  ) : (
                    <Badge className="bg-green-100 text-green-800 border text-[10px]">✓ No Deforestation</Badge>
                  )}
                </div>
                <span className="text-xs text-muted-foreground">{new Date(item.assessmentDate).toLocaleDateString()}</span>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Risk Score</span>
                  <span className={`font-bold font-mono ${getRiskScoreColor(item.riskScore)}`}>{item.riskScore}/100</span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${getRiskBarColor(item.riskScore)}`} style={{ width: `${Math.min(item.riskScore, 100)}%` }} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-green-50 dark:bg-green-950/30 rounded-lg text-center">
                  <p className="text-[10px] text-green-600 font-medium">Baseline Cover</p>
                  <p className="text-lg font-bold font-mono text-green-700">{item.forestCoverBaselinePct}%</p>
                </div>
                <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg text-center">
                  <p className="text-[10px] text-blue-600 font-medium">Current Cover</p>
                  <p className="text-lg font-bold font-mono text-blue-700">{item.currentForestCoverPct}%</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div><span className="text-muted-foreground">Forest Loss:</span><p className={`font-mono font-medium ${item.forestLossPct > 5 ? 'text-red-600' : ''}`}>{item.forestLossPct.toFixed(1)}%</p></div>
                <div><span className="text-muted-foreground">Confidence:</span><p className="font-mono">{(item.confidenceLevel * 100).toFixed(0)}%</p></div>
                <div><span className="text-muted-foreground">Provider:</span><p>{item.provider.toUpperCase()}</p></div>
                <div><span className="text-muted-foreground">Data Source:</span><p className="capitalize">{item.dataSource.replace('_', ' ')}</p></div>
                <div><span className="text-muted-foreground">Methodology:</span><p>{item.methodology}</p></div>
                <div><span className="text-muted-foreground">Valid Until:</span><p>{new Date(item.validUntil).toLocaleDateString()}</p></div>
              </div>
              <div className="text-[10px] text-muted-foreground">
                Reference Period: {new Date(item.referencePeriodStart).toLocaleDateString()} — {new Date(item.referencePeriodEnd).toLocaleDateString()}
              </div>
            </CardContent>
          </Card>
        </FadeIn>
      ))}
    </div>
  )
}

// ─── DDS Tracker Tab for Detail ──────────────────────────────────

function DetailDDSTab({ ddsRecords }: { ddsRecords: DDSRecord[] }) {
  const statusIcon = (status: string) => {
    switch (status) {
      case 'accepted': return <CheckCircle2 className="w-4 h-4 text-green-600" />
      case 'rejected': return <AlertTriangle className="w-4 h-4 text-red-600" />
      case 'pending_review': return <Clock className="w-4 h-4 text-yellow-600" />
      case 'submitted': return <Send className="w-4 h-4 text-blue-600" />
      default: return <FileText className="w-4 h-4 text-gray-500" />
    }
  }

  if (ddsRecords.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
        <FileText className="w-12 h-12 mb-3 opacity-30" />
        <p className="text-sm">No DDS records found for this compliance record</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Pipeline */}
      <FadeIn>
        <Card className="rounded-xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="w-4 h-4" /> DDS Submission Pipeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {ddsRecords.map((item, i) => (
                <div key={item.id} className="flex items-center gap-2">
                  <div className="flex flex-col items-center p-3 rounded-lg border min-w-[120px] bg-muted/30">
                    {statusIcon(item.status)}
                    <Badge className={`${DDS_STATUS_COLORS[item.status] || ''} border capitalize text-[9px] mt-1`}>{item.status.replace('_', ' ')}</Badge>
                    <p className="text-[10px] text-muted-foreground mt-1">{item.complianceId}</p>
                  </div>
                  {i < ddsRecords.length - 1 && <ChevronLeft className="w-4 h-4 text-muted-foreground flex-shrink-0 rotate-180" />}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </FadeIn>

      {/* DDS Table */}
      <FadeIn delay={0.1}>
        <Card className="rounded-xl">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Status</TableHead>
                  <TableHead className="text-xs">Submitted</TableHead>
                  <TableHead className="text-xs">Accepted</TableHead>
                  <TableHead className="text-xs">TRACES Reference</TableHead>
                  <TableHead className="text-xs">Document</TableHead>
                  <TableHead className="text-xs">Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ddsRecords.map((item) => (
                  <TableRow key={item.id} className="hover:bg-muted/50 transition-colors">
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        {statusIcon(item.status)}
                        <Badge className={`${DDS_STATUS_COLORS[item.status] || ''} border capitalize text-[10px]`}>{item.status.replace('_', ' ')}</Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs font-mono">{item.submittedDate ? new Date(item.submittedDate).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="text-xs font-mono">{item.acceptedDate ? new Date(item.acceptedDate).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="font-mono text-[10px]">{item.tracesRef || '—'}</TableCell>
                    <TableCell>
                      {item.documentUrl ? (
                        <a href={item.documentUrl} className="text-primary hover:underline text-xs flex items-center gap-1"><ExternalLink className="w-3 h-3" /> View</a>
                      ) : <span className="text-xs text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-xs max-w-[200px] truncate">{item.notes || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  )
}

// ─── Edit Mode (Inline Wizard) ───────────────────────────────────

function EditWizardForm({ record, onSave, onCancel }: { record: any; onSave: () => void; onCancel: () => void }) {
  const [step, setStep] = useState(0)
  const [form, setForm] = useState<any>({
    complianceId: record.complianceId, batchId: record.batchId || '',
    farmerId: record.farmerId || '', farmLandId: record.farmLandId || '',
    status: record.status, riskLevel: record.riskLevel,
    deforestationRiskScore: record.deforestationRiskScore,
    geolocationLat: record.geolocationLat, geolocationLng: record.geolocationLng,
    landUseType: record.landUseType || '', landCoverChangeDate: record.landCoverChangeDate || '',
    satelliteImageryRef: record.satelliteImageryRef || '',
    verificationDate: record.verificationDate || '', verifiedBy: record.verifiedBy || '',
    dueDiligenceStatement: record.dueDiligenceStatement || '',
    tracesCertificateRef: record.tracesCertificateRef || '',
    validFrom: record.validFrom || '', validUntil: record.validUntil || '',
    notes: record.notes || '', metadata: record.metadata ? JSON.stringify(record.metadata) : '',
  })

  const updateForm = (field: string, value: any) => setForm({ ...form, [field]: value })

  const canAdvance = () => {
    if (step === 0 && !form.complianceId) return false
    return true
  }

  return (
    <div className="space-y-4">
      {/* Step Indicator */}
      <div className="flex items-center gap-1 mb-4">
        {WIZARD_STEPS.map((label, i) => (
          <div key={label} className="flex items-center gap-1 flex-1">
            <div className={`flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold transition-colors
              ${i === step ? 'bg-primary text-primary-foreground' : i < step ? 'bg-green-500 text-white' : 'bg-muted text-muted-foreground'}`}>
              {i < step ? '✓' : i + 1}
            </div>
            <span className={`text-[10px] hidden sm:inline ${i === step ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>{label}</span>
            {i < WIZARD_STEPS.length - 1 && <div className="flex-1 h-px bg-border mx-1" />}
          </div>
        ))}
      </div>

      <Separator />

      {/* Step 0: Basic Info */}
      {step === 0 && (
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2"><Label className="text-xs">Compliance ID *</Label><Input placeholder="EUDR-2024-XXX" value={form.complianceId || ''} onChange={e => updateForm('complianceId', e.target.value)} className="font-mono text-sm" /></div>
            <div className="space-y-2"><Label className="text-xs">Batch ID</Label><Input placeholder="BATCH-XXX" value={form.batchId || ''} onChange={e => updateForm('batchId', e.target.value)} className="font-mono text-sm" /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2"><Label className="text-xs">Farmer ID</Label><Input placeholder="F-XXX" value={form.farmerId || ''} onChange={e => updateForm('farmerId', e.target.value)} className="font-mono text-sm" /></div>
            <div className="space-y-2"><Label className="text-xs">Farm Land ID</Label><Input placeholder="FL-XXX" value={form.farmLandId || ''} onChange={e => updateForm('farmLandId', e.target.value)} className="font-mono text-sm" /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-xs">Status</Label>
              <Select value={form.status || 'pending'} onValueChange={v => updateForm('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_review">In Review</SelectItem>
                  <SelectItem value="compliant">Compliant</SelectItem>
                  <SelectItem value="non_compliant">Non-Compliant</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Risk Level</Label>
              <Select value={form.riskLevel || 'low'} onValueChange={v => updateForm('riskLevel', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      )}

      {/* Step 1: Geolocation & Land */}
      {step === 1 && (
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2"><Label className="text-xs">Latitude</Label><Input type="number" step="0.0001" placeholder="11.9404" value={form.geolocationLat || ''} onChange={e => updateForm('geolocationLat', parseFloat(e.target.value) || undefined)} className="font-mono text-sm" /></div>
            <div className="space-y-2"><Label className="text-xs">Longitude</Label><Input type="number" step="0.0001" placeholder="108.4584" value={form.geolocationLng || ''} onChange={e => updateForm('geolocationLng', parseFloat(e.target.value) || undefined)} className="font-mono text-sm" /></div>
          </div>
          {(form.geolocationLat && form.geolocationLng) ? (
            <GeoLocationMap lat={form.geolocationLat} lng={form.geolocationLng} height="300px" popupText={`${form.complianceId || 'Record'} — Geolocation Preview`} />
          ) : (
            <div className="h-[300px] bg-muted/30 rounded-lg flex items-center justify-center border border-dashed border-muted-foreground/20">
              <div className="text-center"><MapPin className="w-8 h-8 mx-auto text-muted-foreground/30 mb-2" /><p className="text-sm text-muted-foreground">Enter coordinates to preview location</p></div>
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-xs">Land Use Type</Label>
              <Select value={form.landUseType || ''} onValueChange={v => updateForm('landUseType', v)}>
                <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="agroforestry">Agroforestry</SelectItem>
                  <SelectItem value="monoculture">Monoculture</SelectItem>
                  <SelectItem value="shade_grown">Shade Grown</SelectItem>
                  <SelectItem value="mixed_use">Mixed Use</SelectItem>
                  <SelectItem value="cleared_land">Cleared Land</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label className="text-xs">Land Cover Change Date</Label><Input type="date" value={form.landCoverChangeDate || ''} onChange={e => updateForm('landCoverChangeDate', e.target.value)} className="text-sm" /></div>
          </div>
          <div className="space-y-2"><Label className="text-xs">Satellite Imagery Reference</Label><Input placeholder="SAT-GFW-2024-XXX" value={form.satelliteImageryRef || ''} onChange={e => updateForm('satelliteImageryRef', e.target.value)} className="font-mono text-sm" /></div>
        </div>
      )}

      {/* Step 2: Risk Assessment */}
      {step === 2 && (
        <div className="space-y-4 py-2">
          <div className="space-y-2"><Label className="text-xs">Deforestation Risk Score (0-100)</Label><Input type="number" min="0" max="100" placeholder="0-100" value={form.deforestationRiskScore ?? ''} onChange={e => updateForm('deforestationRiskScore', parseInt(e.target.value) || undefined)} className="font-mono text-sm" /></div>
          {form.deforestationRiskScore != null && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Risk Visualization</span><span className={`font-bold font-mono ${getRiskScoreColorVal(form.deforestationRiskScore)}`}>{form.deforestationRiskScore}/100</span></div>
              <div className="h-3 bg-muted rounded-full overflow-hidden"><div className={`h-full rounded-full transition-all ${getRiskBarColorVal(form.deforestationRiskScore)}`} style={{ width: `${Math.min(form.deforestationRiskScore, 100)}%` }} /></div>
            </div>
          )}
          <div className="p-3 bg-muted/50 rounded-lg border"><p className="text-xs text-muted-foreground"><strong>EUDR Cutoff Date:</strong> December 31, 2020. Any deforestation after this date renders the commodity non-compliant.</p></div>
        </div>
      )}

      {/* Step 3: Verification & DDS */}
      {step === 3 && (
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2"><Label className="text-xs">Verification Date</Label><Input type="date" value={form.verificationDate || ''} onChange={e => updateForm('verificationDate', e.target.value)} className="text-sm" /></div>
            <div className="space-y-2"><Label className="text-xs">Verified By</Label><Input placeholder="Dr. Name" value={form.verifiedBy || ''} onChange={e => updateForm('verifiedBy', e.target.value)} className="text-sm" /></div>
          </div>
          <div className="space-y-2"><Label className="text-xs">DDS Document URL</Label><Input placeholder="/docs/dds/EUDR-2024-XXX.pdf" value={form.dueDiligenceStatement || ''} onChange={e => updateForm('dueDiligenceStatement', e.target.value)} className="font-mono text-sm" /></div>
          <div className="space-y-2"><Label className="text-xs">TRACES-NT Certificate Reference</Label><Input placeholder="TRACES-NT/VN/2024/XXXXX" value={form.tracesCertificateRef || ''} onChange={e => updateForm('tracesCertificateRef', e.target.value)} className="font-mono text-sm" /></div>
        </div>
      )}

      {/* Step 4: Validity & Notes */}
      {step === 4 && (
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2"><Label className="text-xs">Valid From</Label><Input type="date" value={form.validFrom || ''} onChange={e => updateForm('validFrom', e.target.value)} className="text-sm" /></div>
            <div className="space-y-2"><Label className="text-xs">Valid Until</Label><Input type="date" value={form.validUntil || ''} onChange={e => updateForm('validUntil', e.target.value)} className="text-sm" /></div>
          </div>
          <div className="space-y-2"><Label className="text-xs">Notes</Label><Textarea placeholder="Additional compliance notes..." value={form.notes || ''} onChange={e => updateForm('notes', e.target.value)} rows={4} className="text-sm" /></div>
          <div className="space-y-2"><Label className="text-xs">Metadata (JSON)</Label><Textarea placeholder='{"region": "Lam Dong", "elevation": 1200}' value={form.metadata || ''} onChange={e => updateForm('metadata', e.target.value)} rows={3} className="font-mono text-xs" /></div>
        </div>
      )}

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <Button variant="outline" size="sm" onClick={onCancel} className="text-xs">Cancel</Button>
        <div className="flex gap-2">
          {step > 0 && <Button variant="outline" size="sm" onClick={() => setStep(step - 1)} className="text-xs gap-1"><ChevronLeft className="w-3 h-3" /> Back</Button>}
          {step < WIZARD_STEPS.length - 1 ? (
            <Button size="sm" onClick={() => canAdvance() && setStep(step + 1)} disabled={!canAdvance()} className="text-xs gap-1">Next <ChevronLeft className="w-3 h-3 rotate-180" /></Button>
          ) : (
            <Button size="sm" onClick={onSave} className="text-xs gap-1">Update Record <CheckCircle2 className="w-3 h-3" /></Button>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Main Detail Page ────────────────────────────────────────────

export default function EudrComplianceDetailPage() {
  const router = useRouter()
  const params = useParams()
  const searchParams = useSearchParams()
  const id = params.id as string
  const startInEdit = searchParams.get('edit') === 'true'

  const [editMode, setEditMode] = useState(startInEdit)
  const [activeTab, setActiveTab] = useState('overview')

  const record = getRecordById(id)

  if (!record) {
    return (
      <DashboardShell>
        <div className="flex flex-col items-center justify-center py-24 text-muted-foreground">
          <Shield className="w-16 h-16 mb-4 opacity-30" />
          <h2 className="text-lg font-medium">Record Not Found</h2>
          <p className="text-sm mt-1">EUDR compliance record with ID &quot;{id}&quot; was not found.</p>
          <Link href="/eudr-compliance" className="mt-4">
            <Button variant="outline" size="sm" className="gap-1 text-xs">
              <ArrowLeft className="w-3 h-3" /> Back to EUDR Compliance
            </Button>
          </Link>
        </div>
      </DashboardShell>
    )
  }

  const assessments = getAssessmentsForRecord(id)
  const ddsRecords = getDDSForComplianceId(record.complianceId)

  return (
    <DashboardShell>
      <div className="space-y-6">
        {/* Breadcrumb */}
        <FadeIn>
          <div className="flex items-center gap-2">
            <Link href="/eudr-compliance">
              <Button variant="ghost" size="sm" className="gap-1 text-xs">
                <ChevronLeft className="w-3 h-3" /> Back to EUDR Compliance
              </Button>
            </Link>
          </div>
        </FadeIn>

        {/* Page Header */}
        <FadeIn delay={0.05}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Shield className="w-6 h-6 text-primary" />
                <span>{record.complianceId}</span>
              </h1>
              <p className="text-sm text-muted-foreground">
                {record.farmer?.name || record.farmerId} — {record.farmLand?.farmName || record.farmLandId}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {!editMode ? (
                <Button size="sm" onClick={() => setEditMode(true)} className="gap-1 text-xs">
                  <Pencil className="w-3.5 h-3.5" /> Edit Record
                </Button>
              ) : (
                <Button variant="outline" size="sm" onClick={() => setEditMode(false)} className="gap-1 text-xs">
                  Cancel Editing
                </Button>
              )}
            </div>
          </div>
        </FadeIn>

        {/* Edit Mode or View Mode */}
        {editMode ? (
          <FadeIn delay={0.1}>
            <Card className="rounded-xl">
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Pencil className="w-4 h-4" /> Edit Compliance Record
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EditWizardForm
                  record={record}
                  onSave={() => setEditMode(false)}
                  onCancel={() => setEditMode(false)}
                />
              </CardContent>
            </Card>
          </FadeIn>
        ) : (
          /* View Mode: Tabs */
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="flex flex-wrap gap-1 h-auto p-1">
              <TabsTrigger value="overview" className="text-xs gap-1"><Shield className="w-3.5 h-3.5" /> Overview</TabsTrigger>
              <TabsTrigger value="deforestation" className="text-xs gap-1"><TreePine className="w-3.5 h-3.5" /> Deforestation Assessment</TabsTrigger>
              <TabsTrigger value="dds" className="text-xs gap-1"><FileText className="w-3.5 h-3.5" /> DDS Tracker</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <DetailOverviewTab record={record} />
            </TabsContent>

            <TabsContent value="deforestation">
              <DetailDeforestationTab assessments={assessments} />
            </TabsContent>

            <TabsContent value="dds">
              <DetailDDSTab ddsRecords={ddsRecords} />
            </TabsContent>
          </Tabs>
        )}
      </div>
    </DashboardShell>
  )
}
