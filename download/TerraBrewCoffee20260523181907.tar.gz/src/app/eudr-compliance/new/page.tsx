'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { DashboardShell } from '@/components/layout/dashboard-shell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import {
  Shield, MapPin, CheckCircle2, ChevronLeft, ChevronRight,
} from 'lucide-react'
import { FadeIn } from '@/components/ui/motion'
import { GeoLocationMap } from '@/components/map'

// ─── Wizard Steps ────────────────────────────────────────────────

const WIZARD_STEPS = ['Basic Info', 'Geolocation & Land', 'Risk Assessment', 'Verification & DDS', 'Validity & Notes']

function getRiskScoreColor(score?: number): string {
  if (!score) return 'text-gray-500'
  if (score > 70) return 'text-red-600'
  if (score > 40) return 'text-yellow-600'
  return 'text-green-600'
}

function getRiskBarColor(score?: number): string {
  if (!score) return 'bg-gray-300'
  if (score > 70) return 'bg-red-500'
  if (score > 40) return 'bg-yellow-500'
  return 'bg-green-500'
}

// ─── Page Component ──────────────────────────────────────────────

export default function NewEudrCompliancePage() {
  const router = useRouter()
  const [step, setStep] = useState(0)
  const [form, setForm] = useState<any>({ status: 'pending', riskLevel: 'low' })

  const updateForm = (field: string, value: any) => setForm({ ...form, [field]: value })

  const canAdvance = () => {
    if (step === 0 && !form.complianceId) return false
    return true
  }

  const handleSubmit = () => {
    // In a real app, this would call an API
    router.push('/eudr-compliance')
  }

  const handleCancel = () => {
    router.push('/eudr-compliance')
  }

  return (
    <DashboardShell>
      <div className="space-y-6">
        {/* Breadcrumb / Back */}
        <FadeIn>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleCancel} className="gap-1 text-xs">
              <ChevronLeft className="w-3 h-3" /> Back to EUDR Compliance
            </Button>
          </div>
        </FadeIn>

        {/* Page Header */}
        <FadeIn delay={0.05}>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Shield className="w-6 h-6 text-primary" />
                <span>Create EUDR Compliance Record</span>
              </h1>
              <p className="text-sm text-muted-foreground font-mono">
                New compliance record — follow the wizard steps
              </p>
            </div>
            <Badge variant="outline" className="text-[10px] font-mono gap-1">
              Step {step + 1} of {WIZARD_STEPS.length}
            </Badge>
          </div>
        </FadeIn>

        {/* Step Indicator */}
        <FadeIn delay={0.1}>
          <Card className="rounded-xl">
            <CardContent className="p-4">
              <div className="flex items-center gap-1">
                {WIZARD_STEPS.map((label, i) => (
                  <div key={label} className="flex items-center gap-1 flex-1">
                    <div className={`flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold transition-colors
                      ${i === step ? 'bg-primary text-primary-foreground' : i < step ? 'bg-green-500 text-white' : 'bg-muted text-muted-foreground'}`}>
                      {i < step ? '✓' : i + 1}
                    </div>
                    <span className={`text-[10px] hidden sm:inline ${i === step ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>{label}</span>
                    {i < WIZARD_STEPS.length - 1 && <div className="flex-1 h-px bg-border mx-1" />}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </FadeIn>

        {/* Step Content */}
        <FadeIn delay={0.15}>
          <Card className="rounded-xl">
            <CardHeader>
              <CardTitle className="text-sm font-medium">{WIZARD_STEPS[step]}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Step 0: Basic Info */}
              {step === 0 && (
                <div className="space-y-4 py-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Compliance ID *</Label>
                      <Input placeholder="EUDR-2024-XXX" value={form.complianceId || ''} onChange={e => updateForm('complianceId', e.target.value)} className="font-mono text-sm" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Batch ID</Label>
                      <Input placeholder="BATCH-XXX" value={form.batchId || ''} onChange={e => updateForm('batchId', e.target.value)} className="font-mono text-sm" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Farmer ID</Label>
                      <Input placeholder="F-XXX" value={form.farmerId || ''} onChange={e => updateForm('farmerId', e.target.value)} className="font-mono text-sm" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Farm Land ID</Label>
                      <Input placeholder="FL-XXX" value={form.farmLandId || ''} onChange={e => updateForm('farmLandId', e.target.value)} className="font-mono text-sm" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Status</Label>
                      <Select value={form.status || 'pending'} onValueChange={v => updateForm('status', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in_review">In Review</SelectItem>
                          <SelectItem value="compliant">Compliant</SelectItem>
                          <SelectItem value="non_compliant">Non-Compliant</SelectItem>
                          <SelectItem value="expired">Expired</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Risk Level</Label>
                      <Select value={form.riskLevel || 'low'} onValueChange={v => updateForm('riskLevel', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 1: Geolocation & Land */}
              {step === 1 && (
                <div className="space-y-4 py-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Latitude</Label>
                      <Input type="number" step="0.0001" placeholder="11.9404" value={form.geolocationLat || ''} onChange={e => updateForm('geolocationLat', parseFloat(e.target.value) || undefined)} className="font-mono text-sm" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Longitude</Label>
                      <Input type="number" step="0.0001" placeholder="108.4584" value={form.geolocationLng || ''} onChange={e => updateForm('geolocationLng', parseFloat(e.target.value) || undefined)} className="font-mono text-sm" />
                    </div>
                  </div>
                  {(form.geolocationLat && form.geolocationLng) ? (
                    <GeoLocationMap
                      lat={form.geolocationLat}
                      lng={form.geolocationLng}
                      height="300px"
                      popupText={`${form.complianceId || 'New Record'} — Geolocation Preview`}
                    />
                  ) : (
                    <div className="h-[300px] bg-muted/30 rounded-lg flex items-center justify-center border border-dashed border-muted-foreground/20">
                      <div className="text-center">
                        <MapPin className="w-8 h-8 mx-auto text-muted-foreground/30 mb-2" />
                        <p className="text-sm text-muted-foreground">Enter coordinates to preview location on map</p>
                      </div>
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Land Use Type</Label>
                      <Select value={form.landUseType || ''} onValueChange={v => updateForm('landUseType', v)}>
                        <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="agroforestry">Agroforestry</SelectItem>
                          <SelectItem value="monoculture">Monoculture</SelectItem>
                          <SelectItem value="shade_grown">Shade Grown</SelectItem>
                          <SelectItem value="mixed_use">Mixed Use</SelectItem>
                          <SelectItem value="cleared_land">Cleared Land</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Land Cover Change Date</Label>
                      <Input type="date" value={form.landCoverChangeDate || ''} onChange={e => updateForm('landCoverChangeDate', e.target.value)} className="text-sm" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Satellite Imagery Reference</Label>
                    <Input placeholder="SAT-GFW-2024-XXX" value={form.satelliteImageryRef || ''} onChange={e => updateForm('satelliteImageryRef', e.target.value)} className="font-mono text-sm" />
                  </div>
                </div>
              )}

              {/* Step 2: Risk Assessment */}
              {step === 2 && (
                <div className="space-y-4 py-2">
                  <div className="space-y-2">
                    <Label className="text-xs">Deforestation Risk Score (0-100)</Label>
                    <Input type="number" min="0" max="100" placeholder="0-100" value={form.deforestationRiskScore ?? ''} onChange={e => updateForm('deforestationRiskScore', parseInt(e.target.value) || undefined)} className="font-mono text-sm" />
                  </div>
                  {form.deforestationRiskScore != null && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Risk Visualization</span>
                        <span className={`font-bold font-mono ${getRiskScoreColor(form.deforestationRiskScore)}`}>{form.deforestationRiskScore}/100</span>
                      </div>
                      <div className="h-3 bg-muted rounded-full overflow-hidden">
                        <div className={`h-full rounded-full transition-all ${getRiskBarColor(form.deforestationRiskScore)}`} style={{ width: `${Math.min(form.deforestationRiskScore, 100)}%` }} />
                      </div>
                      <div className="flex justify-between text-[10px] text-muted-foreground">
                        <span>Low (0-40)</span><span>Medium (41-70)</span><span>High (71-100)</span>
                      </div>
                    </div>
                  )}
                  <div className="p-3 bg-muted/50 rounded-lg border">
                    <p className="text-xs text-muted-foreground">
                      <strong>EUDR Cutoff Date:</strong> December 31, 2020. Any deforestation after this date renders the commodity non-compliant.
                      Risk scores are calculated based on satellite imagery analysis, ground survey data, and Global Forest Watch alerts.
                    </p>
                  </div>
                </div>
              )}

              {/* Step 3: Verification & DDS */}
              {step === 3 && (
                <div className="space-y-4 py-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Verification Date</Label>
                      <Input type="date" value={form.verificationDate || ''} onChange={e => updateForm('verificationDate', e.target.value)} className="text-sm" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Verified By</Label>
                      <Input placeholder="Dr. Name" value={form.verifiedBy || ''} onChange={e => updateForm('verifiedBy', e.target.value)} className="text-sm" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Due Diligence Statement (DDS) Document URL</Label>
                    <Input placeholder="/docs/dds/EUDR-2024-XXX.pdf" value={form.dueDiligenceStatement || ''} onChange={e => updateForm('dueDiligenceStatement', e.target.value)} className="font-mono text-sm" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">TRACES-NT Certificate Reference</Label>
                    <Input placeholder="TRACES-NT/VN/2024/XXXXX" value={form.tracesCertificateRef || ''} onChange={e => updateForm('tracesCertificateRef', e.target.value)} className="font-mono text-sm" />
                  </div>
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
                    <p className="text-xs text-blue-800 dark:text-blue-300">
                      <strong>TRACES-NT:</strong> The EU Trade Control and Expert System. All DDS documents must be submitted through TRACES-NT before placing commodities on the EU market.
                    </p>
                  </div>
                </div>
              )}

              {/* Step 4: Validity & Notes */}
              {step === 4 && (
                <div className="space-y-4 py-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Valid From</Label>
                      <Input type="date" value={form.validFrom || ''} onChange={e => updateForm('validFrom', e.target.value)} className="text-sm" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Valid Until</Label>
                      <Input type="date" value={form.validUntil || ''} onChange={e => updateForm('validUntil', e.target.value)} className="text-sm" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Notes</Label>
                    <Textarea placeholder="Additional compliance notes, observations, remediation plans..." value={form.notes || ''} onChange={e => updateForm('notes', e.target.value)} rows={4} className="text-sm" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Metadata (JSON)</Label>
                    <Textarea placeholder='{"region": "Lam Dong", "elevation": 1200}' value={form.metadata || ''} onChange={e => updateForm('metadata', e.target.value)} rows={3} className="font-mono text-xs" />
                  </div>
                </div>
              )}

              <Separator />

              {/* Navigation Buttons */}
              <div className="flex items-center justify-between pt-2">
                <Button variant="outline" size="sm" onClick={handleCancel} className="text-xs">Cancel</Button>
                <div className="flex gap-2">
                  {step > 0 && (
                    <Button variant="outline" size="sm" onClick={() => setStep(step - 1)} className="text-xs gap-1">
                      <ChevronLeft className="w-3 h-3" /> Back
                    </Button>
                  )}
                  {step < WIZARD_STEPS.length - 1 ? (
                    <Button size="sm" onClick={() => canAdvance() && setStep(step + 1)} disabled={!canAdvance()} className="text-xs gap-1">
                      Next <ChevronRight className="w-3 h-3" />
                    </Button>
                  ) : (
                    <Button size="sm" onClick={handleSubmit} className="text-xs gap-1">
                      Create Record <CheckCircle2 className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </FadeIn>
      </div>
    </DashboardShell>
  )
}
