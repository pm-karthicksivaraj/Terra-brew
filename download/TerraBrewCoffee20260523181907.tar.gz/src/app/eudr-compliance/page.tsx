'use client'

import { useState, useMemo } from 'react'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import { DashboardShell } from '@/components/layout/dashboard-shell'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Shield, AlertTriangle, CheckCircle2, Clock, Plus, Search, Loader2, Eye,
  FileCheck, MapPin, Satellite, TreePine, TrendingUp, TrendingDown,
  ChevronRight, ChevronLeft, Download, RefreshCw, FileText, Globe2,
  Activity, BarChart3, CalendarDays, Timer, Upload, ExternalLink,
  ArrowUpRight, ArrowDownRight, Minus, Filter, X, Copy, Send,
  CircleDot, Layers, Zap, Target, Pencil
} from 'lucide-react'
import { FadeIn, StaggerContainer, StaggerItem, MotionCard, hoverScale } from '@/components/ui/motion'
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, AreaChart, Area, LineChart, Line,
  RadialBarChart, RadialBar, Legend, ComposedChart
} from 'recharts'
import {
  STATUS_COLORS, RISK_COLORS, RISK_CHART_COLORS, STATUS_CHART_COLORS, DDS_STATUS_COLORS,
  MOCK_COMPLIANCE_RECORDS, MOCK_DEFORESTATION_ASSESSMENTS, MOCK_DDS_RECORDS,
  RISK_TREND_DATA, REGION_RISK_DATA,
  getRiskScoreColor, getRiskBarColor,
  type EudrRecord, type DeforestationAssessment, type DDSRecord,
} from './_lib/data'

// ─── Overview Dashboard Tab ──────────────────────────────────────

function OverviewTab({ records, ddsRecords }: { records: EudrRecord[]; ddsRecords: DDSRecord[] }) {
  const stats = useMemo(() => {
    const total = records.length
    const compliant = records.filter(i => i.status === 'compliant').length
    const pending = records.filter(i => i.status === 'pending' || i.status === 'in_review').length
    const nonCompliant = records.filter(i => i.status === 'non_compliant').length
    const expired = records.filter(i => i.status === 'expired').length
    const highRisk = records.filter(i => i.riskLevel === 'high' || i.riskLevel === 'critical').length
    const complianceRate = total > 0 ? Math.round((compliant / total) * 100) : 0
    const avgRiskScore = total > 0 ? Math.round(records.reduce((s, i) => s + (i.deforestationRiskScore || 0), 0) / total) : 0
    const upcomingExpirations = records.filter(i => {
      if (!i.validUntil) return false
      const d = new Date(i.validUntil)
      const now = new Date()
      const diff = (d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      return diff > 0 && diff <= 90
    }).length
    return { total, compliant, pending, nonCompliant, expired, highRisk, complianceRate, avgRiskScore, upcomingExpirations }
  }, [records])

  const statusChartData = useMemo(() => {
    return Object.entries(STATUS_CHART_COLORS).map(([key, color]) => ({
      name: key.replace('_', ' '), value: records.filter(i => i.status === key).length, color,
    })).filter(d => d.value > 0)
  }, [records])

  const riskChartData = useMemo(() => {
    return Object.entries(RISK_CHART_COLORS).map(([key, fill]) => ({
      name: key, value: records.filter(i => i.riskLevel === key).length, fill,
    }))
  }, [records])

  const complianceGaugeData = useMemo(() => {
    return [
      { name: 'Compliant', value: stats.compliant, fill: '#22c55e' },
      { name: 'Non-Compliant', value: stats.nonCompliant, fill: '#ef4444' },
      { name: 'Pending/Other', value: stats.total - stats.compliant - stats.nonCompliant, fill: '#eab308' },
    ].filter(d => d.value > 0)
  }, [stats])

  const ddsStatusCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    ddsRecords.forEach(d => { counts[d.status] = (counts[d.status] || 0) + 1 })
    return counts
  }, [ddsRecords])

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <StaggerContainer className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {[
          { label: 'Total Records', value: stats.total, icon: Shield, bg: 'bg-primary/10', color: 'text-primary' },
          { label: 'Compliance Rate', value: `${stats.complianceRate}%`, icon: CheckCircle2, bg: 'bg-green-100', color: 'text-green-600' },
          { label: 'Avg Risk Score', value: stats.avgRiskScore, icon: Target, bg: 'bg-amber-100', color: 'text-amber-600' },
          { label: 'High/Critical Risk', value: stats.highRisk, icon: AlertTriangle, bg: 'bg-red-100', color: 'text-red-600' },
          { label: 'Pending/Review', value: stats.pending, icon: Clock, bg: 'bg-yellow-100', color: 'text-yellow-600' },
          { label: 'Expiring Soon', value: stats.upcomingExpirations, icon: Timer, bg: 'bg-orange-100', color: 'text-orange-600' },
        ].map((card) => (
          <StaggerItem key={card.label}>
            <MotionCard {...hoverScale} className="rounded-xl border shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${card.bg}`}><card.icon className={`w-4 h-4 ${card.color}`} /></div>
                  <div>
                    <p className="text-xl font-bold font-mono">{card.value}</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">{card.label}</p>
                  </div>
                </div>
              </CardContent>
            </MotionCard>
          </StaggerItem>
        ))}
      </StaggerContainer>

      {/* Charts Row */}
      <div className="grid md:grid-cols-3 gap-6">
        <FadeIn>
          <Card className="rounded-xl">
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Compliance Rate</CardTitle></CardHeader>
            <CardContent>
              <div className="flex items-center justify-center">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={complianceGaugeData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} dataKey="value" strokeWidth={2}>
                      {complianceGaugeData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="text-center -mt-4">
                <p className="text-3xl font-bold font-mono">{stats.complianceRate}%</p>
                <p className="text-xs text-muted-foreground">Overall Compliance</p>
              </div>
            </CardContent>
          </Card>
        </FadeIn>

        <FadeIn delay={0.1}>
          <Card className="rounded-xl">
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Status Distribution</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={statusChartData} cx="50%" cy="50%" outerRadius={80} dataKey="value"
                    label={(props: any) => `${props.name ?? ''} (${((props.percent ?? 0) * 100).toFixed(0)}%)`}>
                    {statusChartData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </FadeIn>

        <FadeIn delay={0.2}>
          <Card className="rounded-xl">
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Risk Level Distribution</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={riskChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                    {riskChartData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </FadeIn>
      </div>

      {/* DDS Tracker & Upcoming Expirations */}
      <div className="grid md:grid-cols-2 gap-6">
        <FadeIn delay={0.1}>
          <Card className="rounded-xl">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <FileText className="w-4 h-4" /> DDS Submission Tracker
                </CardTitle>
                <Badge variant="outline" className="text-[10px]">{ddsRecords.length} Total</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(DDS_STATUS_COLORS).map(([status, cls]) => (
                <div key={status} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge className={`${cls} border capitalize text-[10px]`}>{status.replace('_', ' ')}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-medium">{ddsStatusCounts[status] || 0}</span>
                    <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${status === 'accepted' ? 'bg-green-500' : status === 'rejected' ? 'bg-red-500' : status === 'submitted' ? 'bg-blue-500' : status === 'pending_review' ? 'bg-yellow-500' : 'bg-gray-400'}`}
                        style={{ width: `${ddsRecords.length > 0 ? ((ddsStatusCounts[status] || 0) / ddsRecords.length) * 100 : 0}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </FadeIn>

        <FadeIn delay={0.2}>
          <Card className="rounded-xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <CalendarDays className="w-4 h-4" /> Upcoming Expirations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 max-h-64 overflow-y-auto">
              {records.filter(r => r.validUntil && r.status === 'compliant').sort((a, b) => new Date(a.validUntil!).getTime() - new Date(b.validUntil!).getTime()).slice(0, 5).map(r => {
                const daysLeft = Math.ceil((new Date(r.validUntil!).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
                return (
                  <div key={r.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                    <div>
                      <p className="text-xs font-medium font-mono">{r.complianceId}</p>
                      <p className="text-[10px] text-muted-foreground">{r.farmer?.name}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-xs font-mono font-medium ${daysLeft <= 30 ? 'text-red-600' : daysLeft <= 90 ? 'text-yellow-600' : 'text-green-600'}`}>
                        {daysLeft > 0 ? `${daysLeft}d` : 'Expired'}
                      </p>
                      <p className="text-[10px] text-muted-foreground">{new Date(r.validUntil!).toLocaleDateString()}</p>
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </FadeIn>
      </div>
    </div>
  )
}

// ─── Compliance Records Tab ──────────────────────────────────────

function ComplianceRecordsTab({ records }: { records: EudrRecord[] }) {
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [riskFilter, setRiskFilter] = useState<string>('all')
  const [validityFilter, setValidityFilter] = useState<string>('all')
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())

  const filtered = useMemo(() => {
    return records.filter(r => {
      if (search && !r.complianceId.toLowerCase().includes(search.toLowerCase()) && !(r.farmer?.name || '').toLowerCase().includes(search.toLowerCase())) return false
      if (statusFilter !== 'all' && r.status !== statusFilter) return false
      if (riskFilter !== 'all' && r.riskLevel !== riskFilter) return false
      if (validityFilter === 'valid' && r.status !== 'compliant') return false
      if (validityFilter === 'expiring' && r.validUntil) {
        const d = new Date(r.validUntil)
        const diff = (d.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
        if (!(diff > 0 && diff <= 90)) return false
      }
      if (validityFilter === 'expired' && r.status !== 'expired') return false
      return true
    })
  }, [records, search, statusFilter, riskFilter, validityFilter])

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds)
    if (next.has(id)) { next.delete(id) } else { next.add(id) }
    setSelectedIds(next)
  }

  const toggleAll = () => {
    if (selectedIds.size === filtered.length) setSelectedIds(new Set())
    else setSelectedIds(new Set(filtered.map(r => r.id)))
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <FadeIn>
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input className="pl-9" placeholder="Search by ID or farmer..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {Object.keys(STATUS_COLORS).map(s => <SelectItem key={s} value={s}>{s.replace('_', ' ')}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={riskFilter} onValueChange={setRiskFilter}>
            <SelectTrigger className="w-[140px]"><SelectValue placeholder="Risk" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Risks</SelectItem>
              {Object.keys(RISK_COLORS).map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={validityFilter} onValueChange={setValidityFilter}>
            <SelectTrigger className="w-[140px]"><SelectValue placeholder="Validity" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="valid">Valid</SelectItem>
              <SelectItem value="expiring">Expiring Soon</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
            </SelectContent>
          </Select>
          <Link href="/eudr-compliance/new">
            <Button size="sm" className="gap-1 text-xs whitespace-nowrap">
              <Plus className="w-3.5 h-3.5" /> New Record
            </Button>
          </Link>
        </div>
      </FadeIn>

      {/* Bulk Actions */}
      {selectedIds.size > 0 && (
        <FadeIn>
          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg border">
            <span className="text-xs font-medium">{selectedIds.size} selected</span>
            <Button variant="outline" size="sm" className="text-xs gap-1"><Download className="w-3 h-3" /> Export</Button>
            <Button variant="outline" size="sm" className="text-xs gap-1"><RefreshCw className="w-3 h-3" /> Re-Assess</Button>
            <Button variant="ghost" size="sm" className="text-xs" onClick={() => setSelectedIds(new Set())}>Clear</Button>
          </div>
        </FadeIn>
      )}

      {/* Data Table */}
      <FadeIn delay={0.1}>
        <Card className="rounded-xl">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">
                      <Checkbox checked={selectedIds.size === filtered.length && filtered.length > 0} onCheckedChange={toggleAll} />
                    </TableHead>
                    <TableHead className="font-mono text-xs">Compliance ID</TableHead>
                    <TableHead className="text-xs">Farmer</TableHead>
                    <TableHead className="text-xs">Farm Land</TableHead>
                    <TableHead className="text-xs">Status</TableHead>
                    <TableHead className="text-xs">Risk</TableHead>
                    <TableHead className="text-xs">Risk Score</TableHead>
                    <TableHead className="text-xs">Land Use</TableHead>
                    <TableHead className="text-xs">Valid Until</TableHead>
                    <TableHead className="text-xs">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={10} className="text-center py-12 text-muted-foreground">
                        <Shield className="w-10 h-10 mx-auto mb-2 opacity-40" />
                        <p className="text-sm">No compliance records found</p>
                      </TableCell>
                    </TableRow>
                  ) : filtered.map((item) => (
                    <TableRow key={item.id} className="group hover:bg-muted/50 transition-colors">
                      <TableCell>
                        <Checkbox checked={selectedIds.has(item.id)} onCheckedChange={() => toggleSelect(item.id)} />
                      </TableCell>
                      <TableCell className="font-mono text-xs font-medium">{item.complianceId}</TableCell>
                      <TableCell className="text-xs">{item.farmer?.name || item.farmerId || '—'}</TableCell>
                      <TableCell className="text-xs">{item.farmLand?.farmName || item.farmLandId || '—'}</TableCell>
                      <TableCell>
                        <Badge className={`${STATUS_COLORS[item.status] || ''} border capitalize text-[10px]`}>{item.status?.replace('_', ' ')}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${RISK_COLORS[item.riskLevel] || ''} border capitalize text-[10px]`}>{item.riskLevel}</Badge>
                      </TableCell>
                      <TableCell>
                        {item.deforestationRiskScore != null ? (
                          <span className={`font-mono font-medium text-xs ${getRiskScoreColor(item.deforestationRiskScore)}`}>
                            {item.deforestationRiskScore}/100
                          </span>
                        ) : '—'}
                      </TableCell>
                      <TableCell className="text-xs capitalize">{item.landUseType?.replace('_', ' ') || '—'}</TableCell>
                      <TableCell className="text-xs font-mono">{item.validUntil ? new Date(item.validUntil).toLocaleDateString() : '—'}</TableCell>
                      <TableCell>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Link href={`/eudr-compliance/${item.id}`}>
                            <Button variant="ghost" size="sm" className="h-7 w-7 p-0"><Eye className="w-3.5 h-3.5" /></Button>
                          </Link>
                          <Link href={`/eudr-compliance/${item.id}?edit=true`}>
                            <Button variant="ghost" size="sm" className="h-7 w-7 p-0"><Pencil className="w-3.5 h-3.5" /></Button>
                          </Link>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  )
}

// ─── Deforestation Assessment Tab ────────────────────────────────

function DeforestationTab({ assessments }: { assessments: DeforestationAssessment[] }) {
  const [dialogOpen, setDialogOpen] = useState(false)
  const [detailItem, setDetailItem] = useState<DeforestationAssessment | null>(null)
  const [form, setForm] = useState<any>({ riskCategory: 'low', dataSource: 'satellite', provider: 'gfw', deforestationDetected: false })

  const updateForm = (field: string, value: any) => setForm({ ...form, [field]: value })

  return (
    <div className="space-y-6">
      {/* Summary */}
      <StaggerContainer className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Assessments', value: assessments.length, icon: Satellite, bg: 'bg-primary/10', color: 'text-primary' },
          { label: 'Deforested', value: assessments.filter(a => a.deforestationDetected).length, icon: AlertTriangle, bg: 'bg-red-100', color: 'text-red-600' },
          { label: 'Avg Confidence', value: `${Math.round(assessments.reduce((s, a) => s + a.confidenceLevel, 0) / assessments.length * 100)}%`, icon: Target, bg: 'bg-blue-100', color: 'text-blue-600' },
          { label: 'Avg Forest Loss', value: `${(assessments.reduce((s, a) => s + a.forestLossPct, 0) / assessments.length).toFixed(1)}%`, icon: TreePine, bg: 'bg-green-100', color: 'text-green-600' },
        ].map((card) => (
          <StaggerItem key={card.label}>
            <MotionCard {...hoverScale} className="rounded-xl border shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${card.bg}`}><card.icon className={`w-4 h-4 ${card.color}`} /></div>
                  <div>
                    <p className="text-lg font-bold font-mono">{card.value}</p>
                    <p className="text-[10px] text-muted-foreground">{card.label}</p>
                  </div>
                </div>
              </CardContent>
            </MotionCard>
          </StaggerItem>
        ))}
      </StaggerContainer>

      {/* Forest Cover Comparison Chart */}
      <FadeIn>
        <Card className="rounded-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TreePine className="w-4 h-4" /> Forest Cover: Baseline vs Current
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <ComposedChart data={assessments.map(a => ({ name: a.farmLandId, baseline: a.forestCoverBaselinePct, current: a.currentForestCoverPct, loss: Math.max(a.forestLossPct, 0) }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} unit="%" />
                <Tooltip />
                <Legend />
                <Bar dataKey="baseline" fill="#22c55e" name="Baseline %" radius={[4, 4, 0, 0]} />
                <Bar dataKey="current" fill="#3b82f6" name="Current %" radius={[4, 4, 0, 0]} />
                <Line dataKey="loss" stroke="#ef4444" name="Loss %" type="monotone" />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </FadeIn>

      {/* Assessment Cards */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Assessment Records</h3>
        <Button size="sm" onClick={() => setDialogOpen(true)} className="gap-1 text-xs">
          <Plus className="w-3.5 h-3.5" /> New Assessment
        </Button>
      </div>

      <StaggerContainer className="grid md:grid-cols-2 gap-4">
        {assessments.map((item) => (
          <StaggerItem key={item.id}>
            <MotionCard {...hoverScale} className="rounded-xl border shadow-sm cursor-pointer" onClick={() => setDetailItem(item)}>
              <CardContent className="p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <Badge className={`${RISK_COLORS[item.riskCategory] || ''} border capitalize text-xs`}>{item.riskCategory}</Badge>
                  {item.deforestationDetected ? (
                    <Badge className="bg-red-100 text-red-800 border border-red-200 text-[10px]">⚠ Deforested</Badge>
                  ) : (
                    <Badge className="bg-green-100 text-green-800 border border-green-200 text-[10px]">✓ Clear</Badge>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Risk Score</span>
                    <span className={`font-bold font-mono ${getRiskScoreColor(item.riskScore)}`}>{item.riskScore}/100</span>
                  </div>
                  <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all ${getRiskBarColor(item.riskScore)}`} style={{ width: `${Math.min(item.riskScore, 100)}%` }} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 bg-green-50 dark:bg-green-950/30 rounded-lg text-center">
                    <p className="text-green-600 font-medium">Baseline</p>
                    <p className="font-mono font-bold text-green-700">{item.forestCoverBaselinePct}%</p>
                  </div>
                  <div className="p-2 bg-blue-50 dark:bg-blue-950/30 rounded-lg text-center">
                    <p className="text-blue-600 font-medium">Current</p>
                    <p className="font-mono font-bold text-blue-700">{item.currentForestCoverPct}%</p>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground space-y-0.5">
                  <p className="flex items-center gap-1"><Layers className="w-3 h-3" /> {item.provider.toUpperCase()} • {item.dataSource.replace('_', ' ')}</p>
                  <p className="flex items-center gap-1"><CalendarDays className="w-3 h-3" /> {new Date(item.assessmentDate).toLocaleDateString()}</p>
                  <p className="flex items-center gap-1"><Target className="w-3 h-3" /> Confidence: {(item.confidenceLevel * 100).toFixed(0)}%</p>
                </div>
              </CardContent>
            </MotionCard>
          </StaggerItem>
        ))}
      </StaggerContainer>
    </div>
  )
}

// ─── Due Diligence Statement Tab ─────────────────────────────────

function DDSTab({ ddsRecords, complianceRecords }: { ddsRecords: DDSRecord[]; complianceRecords: EudrRecord[] }) {
  const statusIcon = (status: string) => {
    switch (status) {
      case 'accepted': return <CheckCircle2 className="w-4 h-4 text-green-600" />
      case 'rejected': return <AlertTriangle className="w-4 h-4 text-red-600" />
      case 'pending_review': return <Clock className="w-4 h-4 text-yellow-600" />
      case 'submitted': return <Send className="w-4 h-4 text-blue-600" />
      default: return <FileText className="w-4 h-4 text-gray-500" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <StaggerContainer className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { label: 'Total DDS', value: ddsRecords.length, bg: 'bg-primary/10', color: 'text-primary' },
          { label: 'Accepted', value: ddsRecords.filter(d => d.status === 'accepted').length, bg: 'bg-green-100', color: 'text-green-600' },
          { label: 'Pending', value: ddsRecords.filter(d => d.status === 'pending_review').length, bg: 'bg-yellow-100', color: 'text-yellow-600' },
          { label: 'Rejected', value: ddsRecords.filter(d => d.status === 'rejected').length, bg: 'bg-red-100', color: 'text-red-600' },
          { label: 'Draft', value: ddsRecords.filter(d => d.status === 'draft').length, bg: 'bg-gray-100', color: 'text-gray-600' },
        ].map((card) => (
          <StaggerItem key={card.label}>
            <MotionCard {...hoverScale} className="rounded-xl border shadow-sm">
              <CardContent className="p-4">
                <p className="text-xl font-bold font-mono">{card.value}</p>
                <p className="text-[10px] text-muted-foreground">{card.label}</p>
              </CardContent>
            </MotionCard>
          </StaggerItem>
        ))}
      </StaggerContainer>

      {/* DDS Pipeline */}
      <FadeIn>
        <Card className="rounded-xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="w-4 h-4" /> DDS Submission Pipeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {['draft', 'submitted', 'pending_review', 'accepted', 'rejected'].map((status, i) => {
                const count = ddsRecords.filter(d => d.status === status).length
                return (
                  <div key={status} className="flex items-center gap-2">
                    <div className="flex flex-col items-center p-3 rounded-lg border min-w-[100px] bg-muted/30">
                      {statusIcon(status)}
                      <p className="text-xs font-medium capitalize mt-1">{status.replace('_', ' ')}</p>
                      <p className="text-lg font-bold font-mono">{count}</p>
                    </div>
                    {i < 4 && <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </FadeIn>

      {/* DDS Records Table */}
      <FadeIn delay={0.1}>
        <h3 className="text-sm font-medium">Due Diligence Statements</h3>
        <Card className="rounded-xl mt-3">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Compliance ID</TableHead>
                  <TableHead className="text-xs">Status</TableHead>
                  <TableHead className="text-xs">Submitted</TableHead>
                  <TableHead className="text-xs">Accepted</TableHead>
                  <TableHead className="text-xs">TRACES Reference</TableHead>
                  <TableHead className="text-xs">Document</TableHead>
                  <TableHead className="text-xs">Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ddsRecords.map((item) => (
                  <TableRow key={item.id} className="hover:bg-muted/50 transition-colors">
                    <TableCell className="font-mono text-xs font-medium">{item.complianceId}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        {statusIcon(item.status)}
                        <Badge className={`${DDS_STATUS_COLORS[item.status] || ''} border capitalize text-[10px]`}>{item.status.replace('_', ' ')}</Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs font-mono">{item.submittedDate ? new Date(item.submittedDate).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="text-xs font-mono">{item.acceptedDate ? new Date(item.acceptedDate).toLocaleDateString() : '—'}</TableCell>
                    <TableCell className="font-mono text-[10px]">{item.tracesRef || '—'}</TableCell>
                    <TableCell>
                      {item.documentUrl ? (
                        <a href={item.documentUrl} className="text-primary hover:underline text-xs flex items-center gap-1"><ExternalLink className="w-3 h-3" /> View</a>
                      ) : <span className="text-xs text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-xs max-w-[200px] truncate">{item.notes || '—'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  )
}

// ─── Risk Analytics Tab ──────────────────────────────────────────

function RiskAnalyticsTab({ records }: { records: EudrRecord[] }) {
  const regionData = REGION_RISK_DATA

  return (
    <div className="space-y-6">
      {/* Risk Trend */}
      <FadeIn>
        <Card className="rounded-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="w-4 h-4" /> Risk Score Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={RISK_TREND_DATA}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Area type="monotone" dataKey="avgScore" stroke="#f97316" fill="#f97316" fillOpacity={0.1} name="Avg Risk Score" />
                <Area type="monotone" dataKey="compliant" stroke="#22c55e" fill="#22c55e" fillOpacity={0.1} name="Compliant %" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </FadeIn>

      {/* Regional Risk */}
      <FadeIn delay={0.1}>
        <Card className="rounded-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Globe2 className="w-4 h-4" /> Regional Risk Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={regionData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" tick={{ fontSize: 10 }} />
                <YAxis dataKey="region" type="category" tick={{ fontSize: 11 }} width={80} />
                <Tooltip />
                <Bar dataKey="avgRisk" name="Avg Risk" radius={[0, 6, 6, 0]}>
                  {regionData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </FadeIn>

      {/* Regional Details */}
      <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {regionData.map((item) => (
          <StaggerItem key={item.region}>
            <MotionCard {...hoverScale} className="rounded-xl border shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-bold">{item.region}</h4>
                  <Badge className={`${item.avgRisk > 40 ? 'bg-orange-100 text-orange-800' : 'bg-green-100 text-green-800'} border text-[10px]`}>
                    Risk: {item.avgRisk}
                  </Badge>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-lg font-bold font-mono">{item.farms}</p>
                    <p className="text-[10px] text-muted-foreground">Farms</p>
                  </div>
                  <div>
                    <p className="text-lg font-bold font-mono text-green-600">{item.compliant}</p>
                    <p className="text-[10px] text-muted-foreground">Compliant</p>
                  </div>
                  <div>
                    <p className="text-lg font-bold font-mono">{Math.round((item.compliant / item.farms) * 100)}%</p>
                    <p className="text-[10px] text-muted-foreground">Rate</p>
                  </div>
                </div>
                <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full rounded-full bg-green-500" style={{ width: `${(item.compliant / item.farms) * 100}%` }} />
                </div>
              </CardContent>
            </MotionCard>
          </StaggerItem>
        ))}
      </StaggerContainer>
    </div>
  )
}

// ─── Main Page ───────────────────────────────────────────────────

export default function EudrCompliancePage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState('overview')

  const complianceRecords = MOCK_COMPLIANCE_RECORDS
  const deforestationAssessments = MOCK_DEFORESTATION_ASSESSMENTS
  const ddsRecords = MOCK_DDS_RECORDS

  return (
    <DashboardShell>
      <div className="space-y-6">
        {/* Page Header */}
        <FadeIn>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Shield className="w-6 h-6 text-primary" />
                <span>EUDR Compliance Hub</span>
              </h1>
              <p className="text-sm text-muted-foreground font-mono">
                EU Deforestation Regulation — Due Diligence & Traceability Management
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-[10px] font-mono gap-1">
                <CircleDot className="w-2.5 h-2.5 text-green-500" /> {complianceRecords.filter(r => r.status === 'compliant').length} Compliant
              </Badge>
              <Badge variant="outline" className="text-[10px] font-mono gap-1">
                <AlertTriangle className="w-2.5 h-2.5 text-red-500" /> {complianceRecords.filter(r => r.riskLevel === 'high' || r.riskLevel === 'critical').length} High Risk
              </Badge>
            </div>
          </div>
        </FadeIn>

        {/* EUDR Reference Notice */}
        <FadeIn delay={0.05}>
          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800 flex gap-3">
            <Shield className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-medium text-amber-800 dark:text-amber-300">EUDR Compliance Notice</p>
              <p className="text-[10px] text-amber-700 dark:text-amber-400 mt-0.5">
                Under the EU Deforestation Regulation (Regulation (EU) 2023/1115), operators must submit a Due Diligence Statement (DDS) before placing coffee on the EU market.
                The cutoff date for deforestation is <strong>December 31, 2020</strong>. Non-compliance can result in fines up to 4% of EU annual turnover.
              </p>
            </div>
          </div>
        </FadeIn>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="flex flex-wrap gap-1 h-auto p-1">
            <TabsTrigger value="overview" className="text-xs gap-1"><Activity className="w-3.5 h-3.5" /> Overview</TabsTrigger>
            <TabsTrigger value="records" className="text-xs gap-1"><Shield className="w-3.5 h-3.5" /> Compliance Records</TabsTrigger>
            <TabsTrigger value="deforestation" className="text-xs gap-1"><TreePine className="w-3.5 h-3.5" /> Deforestation Assessment</TabsTrigger>
            <TabsTrigger value="dds" className="text-xs gap-1"><FileText className="w-3.5 h-3.5" /> Due Diligence</TabsTrigger>
            <TabsTrigger value="analytics" className="text-xs gap-1"><BarChart3 className="w-3.5 h-3.5" /> Risk Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <OverviewTab records={complianceRecords} ddsRecords={ddsRecords} />
          </TabsContent>

          <TabsContent value="records">
            <ComplianceRecordsTab records={complianceRecords} />
          </TabsContent>

          <TabsContent value="deforestation">
            <DeforestationTab assessments={deforestationAssessments} />
          </TabsContent>

          <TabsContent value="dds">
            <DDSTab ddsRecords={ddsRecords} complianceRecords={complianceRecords} />
          </TabsContent>

          <TabsContent value="analytics">
            <RiskAnalyticsTab records={complianceRecords} />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardShell>
  )
}
