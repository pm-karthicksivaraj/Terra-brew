'use client'

import dynamic from 'next/dynamic'

// Farm land geo-plotting map — client-only (Leaflet needs DOM)
export const FarmLandMap = dynamic(
  () => import('@/components/map/farm-land-map').then(m => ({ default: m.FarmLandMap })),
  {
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-[400px] bg-muted/50 rounded-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    ),
  }
)

// Traceability journey map — client-only
export const TraceabilityMap = dynamic(
  () => import('@/components/map/traceability-map').then(m => ({ default: m.TraceabilityMap })),
  {
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-[400px] bg-muted/50 rounded-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    ),
  }
)

// Re-export types
export type { FarmLandPolygon, PolygonCoordinate } from '@/components/map/farm-land-map'
export type { TraceLocation } from '@/components/map/traceability-map'
